/*--------------------------------------------------
 * Recipe:   helloPong_c2v0
 * Name:    helloPong.c
 * Purpose: Pong Prototype
 *--------------------------------------------------
 *
 * Modification History
 * 06.02.14 Created
 * 09.12.15 Updated (uVision5.17 + DFP2.6.0)
 *
 * Dr Mark Fisher, CMP, UEA, Norwich, UK
 *--------------------------------------------------*/

#include "stm32f4xx_hal.h"
#include "GLCD_Config.h"
#include "Board_GLCD.h"
#include "Board_ADC.h"
#include "helloPong.h"

/* Globals */
extern GLCD_FONT     GLCD_Font_16x24;
GameInfo thisGame;

#ifdef __RTX
extern uint32_t os_time;

uint32_t HAL_GetTick(void) {
  return os_time; 
}
#endif

/* Function Prototypes */
void SystemClock_Config(void);

/**
  * System Clock Configuration
  */
void SystemClock_Config(void) {
  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

  /* Enable Power Control clock */
  __HAL_RCC_PWR_CLK_ENABLE();

  /* The voltage scaling allows optimizing the power consumption when the
     device is clocked below the maximum system frequency (see datasheet). */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /* Enable HSE Oscillator and activate PLL with HSE as source */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  HAL_RCC_OscConfig(&RCC_OscInitStruct);

  /* Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2
     clocks dividers */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_PCLK1 |
                                RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5);
}

/**
  * Main function
  */
int main (void) {
  HAL_Init ( );
  SystemClock_Config ( );
	
	game_Initialize();
	ADC_Initialize();
	GLCD_Initialize ();
  GLCD_SetBackgroundColor (GLCD_COLOR_WHITE);
  GLCD_ClearScreen (); 
	GLCD_SetForegroundColor (GLCD_COLOR_BLUE);
  GLCD_SetFont (&GLCD_Font_16x24);
	GLCD_DrawChar ( thisGame.ball.x, thisGame.ball.y, 0x81); 	/* Draw Ball */

	for (;;) {					/* loop forever */
		wait_delay(thisGame.num_ticks);	
    /* update ball position */
		update_ball();
		update_player();
		check_collision();
    /* Draw Ball */
    GLCD_DrawChar ( thisGame.ball.x, thisGame.ball.y, 0x81); 	
  } /* end for */
}



