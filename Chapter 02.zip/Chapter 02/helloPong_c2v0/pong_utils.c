/*--------------------------------------------------
 * Recipe:  helloPong_c2v0
 * Name:    pong_utils.c
 * Purpose: Pong Prototype
 *--------------------------------------------------
 *
 * Modification History
 * 06.02.14 Created
 * 09.12.15 Updated (uVision5.17 + DFP2.6.0)
 *
 * Dr Mark Fisher, CMP, UEA, Norwich, UK
 *--------------------------------------------------*/
#include "stm32f4xx_hal.h"
#include "helloPong.h"
#include "Board_ADC.h"
#include "GLCD_Config.h"
#include "Board_GLCD.h"

/* Globals */
extern GLCD_FONT     GLCD_Font_16x24;
extern GLCD_FONT     GLCD_customFont_16x24;
extern GameInfo thisGame;
BallInfo init_pstn;

/****************************************************
*  game_Init()
*  Initialize some game parameters.
*****************************************************/
void game_Initialize(void) {
	init_pstn.dirn = 1;
	init_pstn.x = (WIDTH-CHAR_W)/2;
	init_pstn.y = (HEIGHT-CHAR_H)/2;
	thisGame.ball = init_pstn;
	thisGame.p1.x = 0;
	thisGame.p1.y = 0;
	thisGame.num_ticks = T_SHORT;
}

/***************************************************
*  undate_ball()
*  update the ball pstn - depending on dirn of travel
****************************************************/
void update_ball(void) {
	switch (thisGame.ball.dirn) {
		case 0: thisGame.ball.x++;
						break;
		case 1: thisGame.ball.x++;
						thisGame.ball.y--;
						break;
		case 2: thisGame.ball.y--;
						break;
		case 3: thisGame.ball.x--;
						thisGame.ball.y--;
						break;
		case 4: thisGame.ball.x--;
						break;
		case 5: thisGame.ball.x--;
						thisGame.ball.y++;
						break;
		case 6: thisGame.ball.y++;
						break;
		case 7: thisGame.ball.x++;
						thisGame.ball.y++;			
	}
	if (thisGame.ball.x<BAR_W) {	 /* reset position */
    wait_delay(T_LONG);
    /* Erase Ball */
    GLCD_DrawChar ( thisGame.ball.x, thisGame.ball.y, ' '); 	
		thisGame.ball = init_pstn;
	}
}

/****************************************************
* update_player(unsigned int *)
* Read the ADC and draw the player 1's paddle				
*****************************************************/
void update_player(void) {

  int adcValue; 
  static int lastValue = 0;

	ADC_StartConversion();
  adcValue = ADC_GetValue ();
	adcValue = (adcValue >> 4) * (HEIGHT-BAR_H)/256;
  /* Erase Paddle */
	GLCD_DrawChar (0, lastValue, ' '); 	
  /* Draw Paddle */
  GLCD_SetFont (&GLCD_customFont_16x24);
	GLCD_DrawChar (0, adcValue, 0x00 ); 	
  GLCD_SetFont (&GLCD_Font_16x24);
	lastValue = adcValue;
	thisGame.p1.y = adcValue;
} 

/****************************************************
*  check_collision(void)
*  check for contact between ball and screen edges
*  and paddle and change direction accordingly
*****************************************************/
void check_collision(void) {
  /* check collision with RH */
  if ((thisGame.ball.x==BAR_W) || 
       thisGame.ball.x==(WIDTH-CHAR_W)) {  
		switch (thisGame.ball.dirn)   /* vert scrn edge */
		{                             /*   or P1 paddle */
			case 0: thisGame.ball.dirn = (thisGame.ball.dirn+4)%8;
							break;
			case 1: thisGame.ball.dirn = (thisGame.ball.dirn+2)%8;
							break;
			case 3: if ( (thisGame.ball.y>=thisGame.p1.y-CHAR_H) && (thisGame.ball.y<=(thisGame.p1.y+BAR_H)) )
								thisGame.ball.dirn = (thisGame.ball.dirn+6)%8;
							else 
					      /* empty statement */; 	
							break;
			case 4: if ( (thisGame.ball.y>=thisGame.p1.y-CHAR_H) && (thisGame.ball.y<=(thisGame.p1.y+BAR_H)) )
						    thisGame.ball.dirn = (thisGame.ball.dirn+4)%8;
							else
								/* empty statement */;
					    break;
			case 5: if ( (thisGame.ball.y>=thisGame.p1.y-CHAR_H) && (thisGame.ball.y<=(thisGame.p1.y+BAR_H)) ) 
						    thisGame.ball.dirn = (thisGame.ball.dirn+2)%8;
					    else 
						    /* empty statement */;
					    break;
			case 7: thisGame.ball.dirn = (thisGame.ball.dirn+6)%8;
							break;
			}
	}
  /* check collision with horiz scrn edge */
	if ((thisGame.ball.y<0) || 
       thisGame.ball.y>(HEIGHT-CHAR_H)) { 
    switch (thisGame.ball.dirn)     
		{
			case 1: thisGame.ball.dirn = (thisGame.ball.dirn+6)%8;
							thisGame.ball.y++;
							break;
			case 2: thisGame.ball.dirn = (thisGame.ball.dirn+4)%8;
							thisGame.ball.y++;
							break;
			case 3: thisGame.ball.dirn = (thisGame.ball.dirn+2)%8;
							thisGame.ball.y++;
							break;
			case 5: thisGame.ball.dirn = (thisGame.ball.dirn+6)%8;
							thisGame.ball.y--;
							break;
			case 6: thisGame.ball.dirn = (thisGame.ball.dirn+4)%8;
							thisGame.ball.y--;
							break;
			case 7: thisGame.ball.dirn = (thisGame.ball.dirn+2)%8;
							thisGame.ball.y--;
							break;
		}
	}
}

