/*--------------------------------------------------
 * Recipe:  helloBlinky_c2v3
 * Name:    multiBlinky.c
 * Purpose: Multiple MCBSTM32F400 LED Flasher
 *          illustrating 'pass-by-reference'
 *--------------------------------------------------
 *
 * Modification History
 * 16.01.14 Created
 * 03.12.15 Updated 
 * (uVision5 v5.17+STM32F4xx_DFP2.6.0)
 *
 * Dr Mark Fisher, CMP, UEA, Norwich, UK
 *--------------------------------------------------*/

#include "stm32f4xx_hal.h"        /* STM32F4xx Defs */
#include "Board_LED.h"
#include "RTE_Components.h"  /* Component selection */

void delay (unsigned int *);      /* Func Prototype */
void SystemClock_Config(void);    /* Func Prototype */

/**
  * System Clock Configuration
  */
void SystemClock_Config(void) {
  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

  /* Enable Power Control clock */
  __HAL_RCC_PWR_CLK_ENABLE();

  /* The voltage scaling allows optimizing the power consumption when the
     device is clocked below the maximum system frequency (see datasheet). */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /* Enable HSE Oscillator and activate PLL with HSE as source */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  HAL_RCC_OscConfig(&RCC_OscInitStruct);

  /* Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2
     clocks dividers */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_PCLK1 |
                                RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5);
}


/**
  * Main function
  */
int main (void) {
  const unsigned int max_LEDs = 8;
  const unsigned int wait_period = 500000;
  unsigned int *ptr;
  unsigned int num_ticks;
  unsigned int num = 0;

  HAL_Init ();    /* Init Hardware Abstraction Layer */
  SystemClock_Config ();            /* Config Clocks */
  
  LED_Initialize();                      /* LED Init */

  for (;;) {                         /* Loop forever */
    LED_On (num);                          /* LED on */
    num_ticks = wait_period;        /* (re)set delay */
    ptr = &num_ticks;              /* assign pointer */
    delay (ptr);              /* call delay function */
    LED_Off (num);                        /* LED off */
    num_ticks = wait_period;        /* (re)set delay */
    delay (ptr);              /* call delay function */
    num = (num+1)%max_LEDs;	/* increment num (mod-8) */
  } /* end for */
} /* end main ( ) */


void delay (unsigned int *p){        /* Function Def */
	
while (*p > 0 ) 
	  *p = *p-1;                               /* Wait */
	
} /* end delay ( ) */
