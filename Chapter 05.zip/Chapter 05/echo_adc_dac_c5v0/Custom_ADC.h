/*--------------------------------------------------
 * Name:    ADC.h
 * Purpose: ADC definitions
 *--------------------------------------------------
 * Modification History
 * 16.04.14 created
 * 22.12.15 updated
 * Mark Fisher, CMP, UEA, Norwich, NR3 2ET
 *--------------------------------------------------*/

#ifndef __CUSTOM_ADC_H
#define __CUSTOM_ADC_H


extern void     ADC_Initialize_and_Set_IRQ (void);

#endif /* __CUSTOM_ADC_H */
