/*--------------------------------------------------
 * Name:    DAC.h
 * Purpose: DAC definitions
 *--------------------------------------------------
 * 
 *--------------------------------------------------*/

#ifndef __DAC_H
#define __DAC_H

extern void DAC_Initialize (void);

#endif /* __DAC_H */
