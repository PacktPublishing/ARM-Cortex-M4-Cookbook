/*--------------------------------------------------
 * Recipe:  echo_adc_dac_c5v0
 * Name:    DAC.c
 * Purpose: Low level ADC functions
 *--------------------------------------------------
 *
 * Modification History
 * 28.04.14 created
 * 22.12.15 updated
 *
 * Mark Fisher, CMP, UEA, Norwich
 *--------------------------------------------------*/

#include "stm32f4xx_hal.h"        /* STM32F4xx Defs */
#include "DAC.h"

/*--------------------------------------------------
 *      DAC_Initialize: Initialize DAC
 *
 * Parameters:  (none)
 * Return:      (none)
 *--------------------------------------------------*/
void DAC_Initialize (void) {
	
	RCC->APB1ENR |= RCC_APB1ENR_DACEN; /* En. DAC clk */
                                   /* En. GPIOA clk */
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN; 
	GPIOA->MODER |= (3UL << 2*4);/* PA4 = Analog mode */

	DAC->CR |= DAC_CR_EN1;						/* Enable DAC 1 */
	DAC->CR |= DAC_CR_BOFF1;	/* Enable DAC 1 OP Buff	*/ 
}
