/*--------------------------------------------------
 * Recipe:  adcISR_c5v0
 * Name:    adcISR.c
 * Purpose: A/D Conversion Demo for MCBSTM32F400
 *          using IRQ
 *--------------------------------------------------
 * Modification History
 * 16.04.14 created
 * 22.12.15 updated uVision5.17 + DFP2.6.0
 *
 * Dr Mark Fisher, UEA, Norwich
 *--------------------------------------------------*/

#include "stm32f4xx_hal.h"
#include "Board_LED.h"
#include "Custom_ADC.h"

#define wait_delay HAL_Delay

/* Globals */
uint32_t adcValue;

#ifdef __RTX
extern uint32_t os_time;

uint32_t HAL_GetTick(void) {
  return os_time; 
}
#endif

/* Function Prototypes */
void SystemClock_Config(void);

/**
  * System Clock Configuration
  */
void SystemClock_Config(void) {
  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

  /* Enable Power Control clock */
  __HAL_RCC_PWR_CLK_ENABLE();

  /* The voltage scaling allows optimizing the power consumption when the
     device is clocked below the maximum system frequency (see datasheet). */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /* Enable HSE Oscillator and activate PLL with HSE as source */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  HAL_RCC_OscConfig(&RCC_OscInitStruct);

  /* Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2
     clocks dividers */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_PCLK1 |
                                RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5);
}

/*--------------------------------------------------
 * ADC IRQ Handler
 *--------------------------------------------------*/
void ADC_IRQHandler (void) {
	
  ADC3->SR &= ~2;       /* Clear EOC interrupt flag */
  adcValue = (ADC3->DR);     /* Get converted value */
  ADC3->CR2 |= (1 << 30);  /* Start next conversion */
			
}
	
/*--------------------------------------------------
  Main function
 *--------------------------------------------------*/
int main (void) {
  
  HAL_Init ( );
  SystemClock_Config ( );


  LED_Initialize ();          /* LED Initialization */
	ADC_Initialize_and_Set_IRQ ();/* ADC Special Init */

  while (1) {              /* output 8-bit adcValue */
		LED_SetOut (adcValue >> 4);	  /* to LEDs        */
    wait_delay ( 100 );                     /* wait */
  }
}
