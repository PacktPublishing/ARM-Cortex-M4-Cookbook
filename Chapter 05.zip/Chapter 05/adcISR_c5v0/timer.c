/*--------------------------------------------------------------
 * Name:    timer.c
 * Purpose: Low level timer functions
 *--------------------------------------------------------------
 * This file was developed from an original by Keil.
 *
 * Modification History
 * 16.04.14 created
 *
 * Mark Fisher, CMP, UEA, Norwich
 *------------------------------------------------------------*/

#include "stm32f4xx.h"               /* STM32F4xx Definitions */
#include "timer.h"

/**************************************************************
 * TIM2_Initialize ( )
 **************************************************************
 * Initializes TIM2
 * Capture Compare 2 Interrupt Flag (CC2IF) generates 
 * interrupts every 100ms (0.1s)
 * SystemCoreClock = 168 MHz - set by SystemInit ( )
 * Refer to Figure 134 of STM Reference Manual RM0090
 * TIMxCLK = SystemCoreClock/2
 * Hence ticks = 0.1 * 168,000,000 / 2 = 8,400,000
 * Prescaler = 8400-1; ARR = 1000-1;
 * Note: Capture Compare Register is left in Reset state
 ***************************************************************/
void TIM2_Initialize (void) {
	const uint16_t PSC_val = 8400;
	const uint16_t ARR_val = 1000;
	
	RCC->APB1ENR |= RCC_APB1ENR_TIM2EN; /* enable clock for TIM2 */

  TIM2->PSC = PSC_val - 1;            /* set prescaler         */
  TIM2->ARR = ARR_val - 1;            /* set auto-reload       */
  TIM2->CR1 = ( 1UL << 0 );           /* set Ctr. Enable (CEN) */
	TIM2->CCMR1 |= ( 3UL << 12 );       /* OC1REF toggles when   */
	                                    /* TIMx_CNT=TIMx_CCR1    */
	TIM2->CCER |= ( 1UL << 4 );					/* CC2E set              */
//  TIM2->DIER = ( 1UL << 2 );				  /* Enable CC2IE          */
//	NVIC_EnableIRQ(TIM2_IRQn);					/* Enable NVIC TIM2 Int. */
	
}
