/*--------------------------------------------------
 * Recipe:  adcTimerISR
 * Name:    ADC.c
 * Purpose: Low level ADC functions
 *--------------------------------------------------
 *
 * Modification History
 * 16.04.14 created
 * 22.12.15 updated
 *
 * Mark Fisher, CMP, UEA, Norwich
 *--------------------------------------------------*/

#include "stm32f4xx_hal.h"        /* STM32F4xx Defs */
#include "Custom_ADC.h"

/*--------------------------------------------------
 * ADC_Initialize_and_Set_IRQ: Initialize ADC
 *                             for this recipe
 *--------------------------------------------------*/
void ADC_Initialize_and_Set_IRQ (void) {
   /* Setup potentiometer pin PF9 (ADC3_7) and ADC3 */

  RCC->APB2ENR |= (1UL <<  10);			/* En. ADC3 clk */
  RCC->AHB1ENR |= (1UL <<   5);    /* En. GPIOF clk */
  GPIOF->MODER |= (3UL << 2*9);/* PF9 = Analog mode */

  ADC3->SQR1   =   0;
  ADC3->SQR2   =   0;
  ADC3->SQR3   =  (7UL <<  0);     /* SQ1 = chan. 7 */
	ADC3->SMPR1  =   0;             /* Chan. 7 sample */
	ADC3->SMPR2  =   (7UL <<  18); /* time = 480 cyc. */
  ADC3->CR1    =  (1UL <<  8);      /* Scan mode on */
	
  ADC3->CR1   |=  ( 1UL <<  5);      /* En. EOC IRQ */
	ADC3->CR2   |=  ( 3UL << 28); /* Trig on both edg */
	ADC3->CR2   |=  ( 3UL << 24);      /* of TIM2_CC2 */
  ADC3->CR2   |=  ( 1UL <<  0);       /* ADC enable */    	
	NVIC_EnableIRQ( ADC_IRQn );         /* Enable IRQ */	
	ADC3->CR2 |= (1 << 30);   /* Start 1st conversion */
}
