/*--------------------------------------------------
 * Recipe:  adcTimerISR
 * Name:    timer.c
 * Purpose: Low level timer functions for recipe
 *--------------------------------------------------
 *
 * Modification History
 * 16.04.14 created
 *
 * Mark Fisher, CMP, UEA, Norwich
 *--------------------------------------------------*/

#include "stm32f4xx_hal.h"        /* STM32F4xx Defs */
#include "timer.h"

/***************************************************
 * TIM2_Initialize ( )
 ***************************************************
 * Initializes TIM2
 * Capture Compare 2 Interrupt Flag (CC2IF)  
 * generates interrupts every 100ms (0.1s)
 * SystemCoreClock = 168 MHz - set by SystemInit ( )
 * Refer to Figure 134 of STM Reference Manual
 * TIMxCLK = SystemCoreClock/2
 * Hence ticks = 0.1 * 168,000,000 / 2 = 8,400,000
 * Prescaler = 8400-1; ARR = 1000-1;
 * Note: Capture Compare Register is left in Reset
 ***************************************************/
void TIM2_Initialize (void) {
	const uint16_t PSC_val = 8400;
	const uint16_t ARR_val = 1000;
	
  /* En. clk for TIM2 */
	RCC->APB1ENR |= RCC_APB1ENR_TIM2EN; 

  TIM2->PSC = PSC_val - 1;        /* set prescaler */
  TIM2->ARR = ARR_val - 1;      /* set auto-reload */
  TIM2->CR1 = ( 1UL << 0 );  /* set Ctr. En. (CEN) */
	TIM2->CCMR1 |= ( 3UL << 12 );  /* OC1REF toggles */
	                      /* when TIMx_CNT=TIMx_CCR1 */
	TIM2->CCER |= ( 1UL << 4 );					 /* CC2E set */
}
