/*--------------------------------------------------
 * Recipe: adcTimerISR
 * Name:    ADC.h
 * Purpose: ADC definitions for recipe
 *--------------------------------------------------
 
 *--------------------------------------------------*/

#ifndef __ADC_H
#define __ADC_H

#include <stdint.h>
#include <stdbool.h>

extern void     ADC_Initialize_and_Set_IRQ (void);

#endif /* __ADC_H */
