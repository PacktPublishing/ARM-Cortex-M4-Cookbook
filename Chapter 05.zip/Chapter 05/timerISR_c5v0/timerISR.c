/*--------------------------------------------------
 * Recipe:  timerISR_c5v0
 * Name:    timerISR.c
 * Purpose: LED Flasher for MCBSTM32F400 using 
 *          General Purpose Timer TIM2
 *--------------------------------------------------
 * Modification History
 * 20.04.14 - Created
 *
 * Mark Fisher, UEA, Norwich, UK
 *--------------------------------------------------*/

#include "stm32f4xx_hal.h"
#include "Board_LED.h"
#include "timer.h"

/* Globals */
uint32_t tic = 0;
 
#ifdef __RTX
extern uint32_t os_time;

uint32_t HAL_GetTick(void) {
  return os_time; 
}
#endif

/* Function Prototypes */
void SystemClock_Config(void);

/**
  * System Clock Configuration
  */
void SystemClock_Config(void) {
  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

  /* Enable Power Control clock */
  __HAL_RCC_PWR_CLK_ENABLE();

  /* The voltage scaling allows optimizing the power consumption when the
     device is clocked below the maximum system frequency (see datasheet). */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /* Enable HSE Oscillator and activate PLL with HSE as source */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  HAL_RCC_OscConfig(&RCC_OscInitStruct);

  /* Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2
     clocks dividers */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_PCLK1 |
                                RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5);
}

/*--------------------------------------------------
  Timer2 Update Interrupt Handler
 *--------------------------------------------------*/
void TIM2_IRQHandler (void) {
  
  /* check IRQ source */
	if ((TIM2->SR & 0x0001) != 0) {
	  tic++; 
		TIM2->SR &= ~(1<<0);         /* clear UIF flag	*/
	}
}


/*--------------------------------------------------
  Main function
 *--------------------------------------------------*/
int main (void) { 
  int32_t num = 0;
  uint32_t toc;
  uint32_t count = 0;
  
  HAL_Init ( );
  SystemClock_Config ( );

	TIM2_Initialize ( );/* Gen. interrupt each 100 ms */
  LED_Initialize();           /* LED Initialization */

  while (1) {
    if (toc != tic) {
      toc = tic;
      LED_Off (num);                   	
    if (count < 7)
      num = (num+1);
    else
      num = (num-1);
    LED_On (num);
    count = (count+1)%14;
    }
  }
}
