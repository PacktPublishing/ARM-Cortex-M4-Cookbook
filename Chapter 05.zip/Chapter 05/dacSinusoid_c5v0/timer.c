/*--------------------------------------------------------------
 * Name:    timer.c
 * Purpose: Low level timer functions
 *--------------------------------------------------------------
 * This file was developed from an original by Keil.
 *
 * Modification History
 * 16.04.14 created
 *
 * Mark Fisher, CMP, UEA, Norwich
 *------------------------------------------------------------*/

#include "stm32f4xx.h"               /* STM32F4xx Definitions */
#include "timer.h"

/**************************************************************
 * TIM2_Initialize ( )
 **************************************************************
 * Initializes TIM2 generates interrupts every 1ms (0.001s)
 * SystemCoreClock = 168 MHz - set by SystemInit ( )
 * Refer to Figure 134 of STM Reference Manual RM0090
 * TIMxCLK = SystemCoreClock/2
 * Hence ticks = 0.001 * 168,000,000 / 2 = 84,000
 * Prescaler = 84-1; ARR = 1000-1;
 ***************************************************************/
void TIM2_Initialize (void) {
	const uint16_t PSC_val = 84;
	const uint16_t ARR_val = 1000;
	
	RCC->APB1ENR |= RCC_APB1ENR_TIM2EN; /* enable clock for TIM2 */

  TIM2->PSC = PSC_val - 1;            /* set prescaler         */
  TIM2->ARR = ARR_val - 1;            /* set auto-reload       */
  TIM2->CR1 = (1UL << 0);             /* set command reg.      */
	TIM2->DIER = (1UL << 0);						/* Enable TIM2 Int.      */
	NVIC_EnableIRQ(TIM2_IRQn);					/* Enable NVIC TIM2 Int. */
	
}	
