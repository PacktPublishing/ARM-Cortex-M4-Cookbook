/*--------------------------------------------------------------
 * Name:    DAC.c
 * Purpose: Low level ADC functions
 *--------------------------------------------------------------
 * This file was developed from an original by Keil.
 *
 * Modification History
 * 28.04.14 created
 *
 * Mark Fisher, CMP, UEA, Norwich
 *------------------------------------------------------------*/

#include "stm32f4xx.h"               /* STM32F4xx Definitions */
#include "DAC.h"

/*--------------------------------------------------------------
 *      DAC_Initialize: Initialize Digital to Analogue Converter
 *
 * Parameters:  (none)
 * Return:      (none)
 *------------------------------------------------------------*/
void DAC_Initialize (void) {
	
	RCC->APB1ENR |= RCC_APB1ENR_DACEN;   /* Enable DAC Clock    */
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN; /* Enable GPIOA clock  */
	GPIOA->MODER |= (3UL << 2*4);        /* PA4 is Analog mode  */

	DAC->CR |= DAC_CR_EN1;						/* Enable DAC 1 					*/
	DAC->CR |= DAC_CR_BOFF1;					/* Enable DAC 1 OP Buff		*/ 
}
