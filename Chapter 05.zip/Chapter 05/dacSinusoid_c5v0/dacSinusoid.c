/*--------------------------------------------------
 * Name:    dacSinusoid.c
 * Purpose: Outputs 5Hz Sine Wave for MCBSTM32F400
 *          
 *          Sine wave samples are stored in LUT
 *--------------------------------------------------
 *
 * Modification History
 * 10.05.14 created
 * 22.12.15 updated uVision5.17+DFP2.6.0
 *
 * Mark Fisher, UEA, Norwich, UK
 *--------------------------------------------------*/

#include "stm32f4xx_hal.h"        /* STM32F4xx Defs */
#include "Board_LED.h"
#include "dac.h"
#include "timer.h"


uint16_t dacLUT [] = {2047, 2680, 3250, 3703, 3994, 
											4095, 3994, 3703, 3250, 2680,
											2047, 1414,  844,  391,  100, 
											0,     100,  391,  844, 1414 };

#ifdef __RTX
extern uint32_t os_time;

uint32_t HAL_GetTick(void) {
  return os_time; 
}
#endif

/* Function Prototypes */
void SystemClock_Config(void);

/**
  * System Clock Configuration
  */
void SystemClock_Config(void) {
  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

  /* Enable Power Control clock */
  __HAL_RCC_PWR_CLK_ENABLE();

  /* The voltage scaling allows optimizing the power consumption when the
     device is clocked below the maximum system frequency (see datasheet). */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /* Enable HSE Oscillator and activate PLL with HSE as source */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  HAL_RCC_OscConfig(&RCC_OscInitStruct);

  /* Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2
     clocks dividers */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_PCLK1 |
                                RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5);
}

                      
/*--------------------------------------------------------------
  TIM2 IRQ Handler
 *------------------------------------------------------------*/
void TIM2_IRQHandler (void) {
	static uint8_t idx = 0;
  
  if (TIM2->SR & (1<<0)) {
		TIM2->SR &= ~(1<<0);						/* clear UIR flag */
		DAC->DHR12R1 = dacLUT[idx++];		/* write LUT value to DAC */
	  idx %= 20;
	  LED_SetOut (idx);									/* Write idx to LEDs      */		
	}

}
	
/*--------------------------------------------------------------
  Main function
 *------------------------------------------------------------*/
int main (void) {
  
  HAL_Init( );
  SystemClock_Config ( );

  LED_Initialize ();            /* LED Initialization         */
	DAC_Initialize ();            /* DAC Initialization         */
	TIM2_Initialize ();

  while (1) {  
			;
	}
}
