 /**************************************************
 * Recipe:   ticToc_c3v0
 * File:     ticTocISR.c 
 * Purpose:  digital clock example using timer                      
 ***************************************************
 *										  			                                
 * Modification History										                    
 * 05.03.14 Created	
 * 15.12.15 Updated (uVision5.17 + DFP2.6.0 
 * 																							              
 * Dr. Mark Fisher, CMP, UEA, Norwich, UK.                                    
 ****************************************************/

#include "stm32F4xx_hal.h"
#include <stdio.h>
#include "Serial.h"
#include "cmsis_os.h"
#include "Board_GLCD.h"
#include "GLCD_Config.h"
#include "ticToc.h"

#define DAY 8640000;        /* 10 ms tics in a day */

/* Global Variables */
extern GLCD_FONT     GLCD_Font_16x24;

#ifdef __RTX
extern uint32_t os_time;

uint32_t HAL_Gettic(void) {
  return os_time; 
}
#endif

/*--------------------------------------------------
  System Clock Configuration
 *--------------------------------------------------*/
void SystemClock_Config(void) {
  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

  /* Enable Power Control clock */
  __HAL_RCC_PWR_CLK_ENABLE();

  /* The voltage scaling allows optimizing the power consumption when the
     device is clocked below the maximum system frequency (see datasheet). */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /* Enable HSE Oscillator and activate PLL with HSE as source */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  HAL_RCC_OscConfig(&RCC_OscInitStruct);

  /* Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2
     clocks dividers */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_PCLK1 |
                                RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5);
}

/*
 * main
 *******/
int main (void) {
	
	time_t time;
	int32_t input;
	char buffer[128];
  
  uint32_t tic, toc = 0; 
  uint32_t elapsed_t;
  
  HAL_Init ();   /* Init Hardware Abstraction Layer */
  SystemClock_Config ();           /* Config Clocks */ 
  	
  SER_Init();

	GLCD_Initialize();
	GLCD_SetBackgroundColor (GLCD_COLOR_WHITE);
  GLCD_ClearScreen ();                    /* clear the GLCD */
  GLCD_SetBackgroundColor (GLCD_COLOR_BLUE);
	GLCD_SetForegroundColor (GLCD_COLOR_WHITE);
  GLCD_SetFont (&GLCD_Font_16x24);
	GLCD_DrawString (0, 0*24, " CORTEX-M4 COOKBOOK ");
  GLCD_DrawString (0, 1*24, "  PACKT Publishing  ");
	GLCD_SetBackgroundColor (GLCD_COLOR_WHITE); 	
	GLCD_SetForegroundColor (GLCD_COLOR_BLACK);

	
	/* Set the current time using PuTTY */
	printf ("Clock Example\n");
	printf ("Set Hours: ");
	scanf("%d", &input); time.hour = input;
	printf ("Set Minutes: ");
	scanf("%d", &input); time.min = input;
	printf ("Set Seconds: ");
	scanf("%d", &input); time.sec = input;
	
	/* elapsed_t is elapsed (10 * msec) since midnight */
	elapsed_t = time.sec*100+time.min*60*100+time.hour*60*60*100;

  
  for (;;) {                        /* Loop forever */ 
    tic = HAL_Gettic()/10;     
		if (tic != toc) {              /* 10 ms update */
      toc = tic;
 
			time.sec = (elapsed_t/100)%60; /* update time */
			time.min = (elapsed_t/6000)%60;
			time.hour = (elapsed_t/360000)%24;

      /* Update Display */
			sprintf(buffer, "%d : %d : %d", time.hour, time.min, time.sec);
      GLCD_DrawString (4*16, 3*24, "             ");
			GLCD_DrawString (4*16, 3*24, buffer);		
      
      elapsed_t = (elapsed_t+1)%DAY;
    }
	}
}
