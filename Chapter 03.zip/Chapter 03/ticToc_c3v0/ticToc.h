#ifndef __TICTOC_H
#define __TICTOC_H

typedef struct {                         /* structure of the clock record     */
  unsigned char    hour;                 /* hour                              */
  unsigned char     min;                 /* minute                            */
  unsigned char     sec;                 /* second                            */
} time_t;


#endif /* __TICTOC_H  */
