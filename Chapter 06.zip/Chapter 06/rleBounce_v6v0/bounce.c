/*-----------------------------------------------------------------------------
 * Name:    bounce.c
 * Purpose: Pong Prototype Version 1
 *-----------------------------------------------------------------------------
 * This file was developed from examples from uVision/ARM development tools.
 *
 * Modification History
 * 06.02.14 Created
 *
 * Dr Mark Fisher, CMP, UEA, Norwich, UK
 *----------------------------------------------------------------------------*/

#include "stm32f4xx.h"              												/* STM32F4xx Definitions */
#include "GLCD_PLUS_RLE.h"
#include "bounce.h"

/* GIMP RGB C-Source image dump (ball_16bit.c) */

/*******************************************************************************
* Display graphical bitmap image at position x horizontally and y vertically   *
* (This function is optimized for RUN LENGTH ENCODED 16 bits per pixel format, *
* it has to be adapted for any other bits per pixel format)                    *
*   Parameter:      x:        horizontal position                              *
*                   y:        vertical position                                *
*                   w:        width of bitmap                                  *
*                   h:        height of bitmap                                 *
*                   bitmap:   address at which the bitmap data resides         *
*   Return:                                                                    *
*******************************************************************************/

void GLCD_RLE_Bitmap (unsigned int x, unsigned int y, 
	                    unsigned int w, unsigned int h, 
										  unsigned char *bitmap) {
  
	unsigned int npix = w * h;
	unsigned int i=0, j;
	unsigned short *bitmap_ptr;
	unsigned char count;
	 
  GLCD_SetWindow (x, y, w, h);
  GLCD_WrCmd(0x22);
	
	while (i<npix) {
		count = *bitmap++;
		bitmap_ptr = (unsigned short *) bitmap;
		if (count >= 128) {
			count = count-128;
			for (j = 0; j<count; j++) { /* repeated pixels */
				LCD_DAT16 = *bitmap_ptr;				
			}
			bitmap+=2; /* adjust the pointer */
		}
		else {
			for (j=0; j<count; j++) 
				LCD_DAT16 = bitmap_ptr[j];
      bitmap+=(count*2); /* adjust the pointer */			
		}
		i+=count;
	} /* for */
}

static const struct {
  unsigned int  	 width;
  unsigned int  	 height;
  unsigned int  	 bytes_per_pixel; /* 2:RGB16, 3:RGB, 4:RGBA */ 
  unsigned char 	 pixel_data[390 + 1];
} rle_gimp_image = {
  16, 24, 2,
  "\325\377\377\5\377\377\0\370\0\370\0\370\0\370\211\377\377\11\377\377\0\370"
  "\0\370\0\370\0\370\0\370\0\370\0\370\0\370\206\377\377\13\377\377\0\370\0"
  "\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\204\377\377\15\377\377"
  "\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370"
  "\203\377\377\15\377\377\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0"
  "\370\0\370\0\370\0\370\202\377\377!\377\377\0\370\0\370\0\370\0\370\0\370"
  "\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\377\377\377\377\0"
  "\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0"
  "\370\0\370\377\377\377\377\215\0\0!\0\0\377\377\377\377\37\0\37\0\37\0\37"
  "\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\377\377\377\377\37\0"
  "\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\202\377"
  "\377\15\377\377\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37"
  "\0\203\377\377\15\377\377\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37"
  "\0\37\0\37\0\204\377\377\13\377\377\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37"
  "\0\37\0\37\0\206\377\377\11\377\377\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37"
  "\0\211\377\377\5\377\377\37\0\37\0\37\0\37\0\305\377\377\1\377\377",
};

void myGLCD_Bitmap (unsigned int x, unsigned int y, unsigned int w, unsigned int h, unsigned char *bitmap) {
  int i;
  unsigned short *bitmap_ptr = (unsigned short *)bitmap;
	unsigned int n = w*h;

  GLCD_SetWindow (x, y, w, h);
  GLCD_WrCmd(0x22);
	
	for (i=0; i<n; i++) 
  	LCD_DAT16 = bitmap_ptr[i];
}

static const struct {
  unsigned int 	 width;
  unsigned int 	 height;
  unsigned int 	 bytes_per_pixel; /* 2:RGB16, 3:RGB, 4:RGBA */ 
  unsigned char	 pixel_data[16 * 24 * 2 + 1];
} gimp_image = {
  16, 24, 2,
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377\377\0\370\0\370\0\370\0\370\377\377"
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\0\370\0\370\0\370\0\370\0\370\0\370\0\370"
  "\0\370\0\370\0\370\377\377\377\377\377\377\377\377\377\377\0\370\0\370\0"
  "\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\377\377\377\377"
  "\377\377\377\377\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0"
  "\370\0\370\0\370\377\377\377\377\377\377\0\370\0\370\0\370\0\370\0\370\0"
  "\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\377\377\377\377\0\370"
  "\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370"
  "\0\370\377\377\377\377\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"
  "\0\0\0\377\377\377\377\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0"
  "\37\0\37\0\37\0\37\0\377\377\377\377\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37"
  "\0\37\0\37\0\37\0\37\0\37\0\37\0\377\377\377\377\377\377\37\0\37\0\37\0\37"
  "\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\377\377\377\377\377\377\377\377"
  "\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\377\377\377"
  "\377\377\377\377\377\377\377\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0"
  "\37\0\377\377\377\377\377\377\377\377\377\377\377\377\377\377\37\0\37\0\37"
  "\0\37\0\37\0\37\0\37\0\37\0\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\37\0\37\0\37\0\37\0\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377",
};

int main (void) {
	unsigned int dirn = 1;
	int x = (WIDTH-CHAR_W)/2, y = (HEIGHT-CHAR_H)/2;					/* initial ball position */
	unsigned long num_ticks = 100000;
	
	GLCD_Initialize ();
	GLCD_Clear (White);                           						/* Clear the GLCD */
	GLCD_SetBackColor (White);                    						/* Set the Back Color */
	GLCD_SetTextColor (Blue);                     						/* Set the Text Color */
//	myGLCD_Bitmap ((unsigned int) x, (unsigned int) y, gimp_image.width, gimp_image.height, (unsigned char *) gimp_image.pixel_data);
  GLCD_RLE_Bitmap ((unsigned int) x, (unsigned int) y, gimp_image.width, gimp_image.height, (unsigned char *) rle_gimp_image.pixel_data);


	for (;;) {					/* loop forever */
		delay(num_ticks);	/* update ball position */
		switch (dirn) {
			case 0: x++;
					    break;
			case 1: x++;
					    y--;
					    break;
			case 2: y--;
              break;
			case 3: x--;
					    y--;
					    break;
			case 4: x--;
					    break;
			case 5: x--;
					    y++;
					    break;
			case 6: y++;
					    break;
			case 7: x++;
					    y++;			
		}
		if ((x==0) || x==(WIDTH-CHAR_W) ) {  /* check collision with */
			switch (dirn)                      /* vertical screen edge */
				{
				case 0: dirn = (dirn+4)%8;
							  break;
				case 1: dirn = (dirn+2)%8;
						    break;
				case 3: dirn = (dirn+6)%8;
						    break;
				case 4: dirn = (dirn+4)%8;
						    break;
				case 5: dirn = (dirn+2)%8;
						    break;
				case 7: dirn = (dirn+6)%8;
						    break;
				}
		}
		if ((y==0) || y==(HEIGHT-CHAR_H) ) { /* check collision with */
			switch (dirn)                      /* horizontal screen edge */
				{
				case 1: dirn = (dirn+6)%8;
						    break;
				case 2: dirn = (dirn+4)%8;
						    break;
				case 3: dirn = (dirn+2)%8;
						    break;
				case 5: dirn = (dirn+6)%8;
						    break;
				case 6: dirn = (dirn+4)%8;
						    break;
				case 7: dirn = (dirn+2)%8;
						    break;
				}
		}
		//myGLCD_Bitmap ((unsigned int) x, (unsigned int) y, gimp_image.width, gimp_image.height, (unsigned char *) gimp_image.pixel_data);
    GLCD_RLE_Bitmap ((unsigned int) x, (unsigned int) y, gimp_image.width, gimp_image.height, (unsigned char *) rle_gimp_image.pixel_data);


  } /* end for */
}

void delay (unsigned int d) {
	unsigned int i;
	
	for (i=0; i<d; i++)
		/* empty statement */;
}


