/*-----------------------------------------------------------------------------
 * Name:    bounce.h
 * Purpose: bounce function prototypes and defines
 *-----------------------------------------------------------------------------
 * This file was developed from examples from uVision/ARM development tools.
 *
 * Modification History
 * 06.02.14 Created
 *
 * Dr Mark Fisher, CMP, UEA, Norwich, UK
 *----------------------------------------------------------------------------*/
#ifndef _BOUNCE_H
#define _BOUNCE_H
#define WIDTH				320
#define HEIGHT			240
#define CHAR_H      24                  /* Character Height (in pixels)       */
#define CHAR_W      16                  /* Character Width (in pixels)        */

extern unsigned short Font_16x24_h[];

void delay (unsigned int );

#endif /* _BOUNCE_H */
