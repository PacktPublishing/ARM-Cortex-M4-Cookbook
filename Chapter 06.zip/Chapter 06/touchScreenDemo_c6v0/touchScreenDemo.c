/*--------------------------------------------------
 * Recipe:  touchScreenDemo_c6v0
 * Name:    touchScreenDemo.c
 * Purpose: Demo example for MCBSTM32F400
 * Note(s):
 *--------------------------------------------------
 * Revision History
 * 05.2014 Created
 * 28.12.2015 Updated (uVision5.16+DFP2.6.0)
 *
 * Mark Fisher, CMP, UEA, Norwich.
 *--------------------------------------------------*/

#include <stdio.h>
#include "stm32f4xx_hal.h"
#include "cmsis_os.h"
#include "Driver_I2C.h"
#include "Board_GLCD.h"
#include "GLCD_Config.h"
#include "Board_Touch.h"

#define SCREEN_TS_WIDTH		4000	// The size of the touch-screen co-ordinates system.
#define SCREEN_TS_HEIGHT	4000
#define wait_delay HAL_Delay

/* Globals */
extern GLCD_FONT     GLCD_Font_16x24;

/* Function Prototypes */
void screenTransformTS(TOUCH_STATE *ts);
void SystemClock_Config(void);
void setDisplay(void);
void updateDisplay(TOUCH_STATE  *tsc_state);
void clearDisplay(void);


#ifdef __RTX
extern uint32_t os_time;

uint32_t HAL_GetTick(void) {
  return os_time; 
}
#endif

/**
  * System Clock Configuration
  */
void SystemClock_Config(void) {
  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

  /* Enable Power Control clock */
  __HAL_RCC_PWR_CLK_ENABLE();

  /* The voltage scaling allows optimizing the power consumption when the
     device is clocked below the maximum system frequency (see datasheet). */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /* Enable HSE Oscillator and activate PLL with HSE as source */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  HAL_RCC_OscConfig(&RCC_OscInitStruct);

  /* Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2
     clocks dividers */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_PCLK1 |
                                RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5);
}

/*--------------------------------------------------
  Touch Screen Transform
 *--------------------------------------------------*/
void screenTransformTS(TOUCH_STATE *ts) {
	
	int y = ts->y;
  int x = ts->x;
	// Note: co-ordinates are inverted
	if(x > 0)
		ts->y = GLCD_HEIGHT - (int)(((double)x / 
              (double)SCREEN_TS_HEIGHT)*(double)GLCD_HEIGHT);
	if(y > 0)
		ts->x = (int)(((double)y /
              (double)SCREEN_TS_WIDTH)*(double)GLCD_WIDTH);
}

/*--------------------------------------------------
  setDisplay
 *--------------------------------------------------*/
void setDisplay( ) {
  GLCD_SetBackgroundColor (GLCD_COLOR_WHITE);
  GLCD_ClearScreen ();  /* clear the GLCD */
  
  GLCD_SetBackgroundColor (GLCD_COLOR_BLUE);
	GLCD_SetForegroundColor (GLCD_COLOR_WHITE);
  GLCD_SetFont (&GLCD_Font_16x24);
	GLCD_DrawString (0, 0*24, " CORTEX-M4 COOKBOOK ");
  GLCD_DrawString (0, 1*24, "  PACKT Publishing  ");
  
  GLCD_SetBackgroundColor (GLCD_COLOR_WHITE); 	
	GLCD_SetForegroundColor (GLCD_COLOR_BLACK);

  GLCD_DrawString (0, 3*24, "Touch:");
  GLCD_DrawString (0, 4*24, "x    :");
  GLCD_DrawString (0, 5*24, "y    :");
  GLCD_DrawString (0, 6*24, "xt   :");
  GLCD_DrawString (0, 7*24, "yt   :");
}

/*--------------------------------------------------
  updateDisplay
 *--------------------------------------------------*/
void updateDisplay(TOUCH_STATE  *tsc_state) {
  char buffer[128];
  
  GLCD_SetForegroundColor (GLCD_COLOR_BLACK);
  GLCD_DrawString (7*16, 3*24, "DETECTED");
  sprintf(buffer, "%i   ", tsc_state->x);	 	/* raw x_coord */
  GLCD_DrawString (7*16, 4*24, buffer);
  
  sprintf(buffer, "%i   ", tsc_state->y);	  /* raw y_coord */
  GLCD_DrawString (7*16, 5*24, buffer);
  
  screenTransformTS(tsc_state);
  sprintf(buffer, "%i   ", tsc_state->x);
  GLCD_DrawString (7*16, 6*24, buffer);
  
  sprintf(buffer, "%i   ", tsc_state->y);
  GLCD_DrawString (7*16, 7*24, buffer);
}

/*--------------------------------------------------
  clearDisplay
 *--------------------------------------------------*/
void clearDisplay() {
  GLCD_SetForegroundColor (GLCD_COLOR_LIGHT_GREY);
  GLCD_DrawString (7*16, 3*24, "DETECTED");
  GLCD_DrawString (7*16, 4*24, "        ");
  GLCD_DrawString (7*16, 5*24, "        ");
  GLCD_DrawString (7*16, 6*24, "        ");
  GLCD_DrawString (7*16, 7*24, "        ");
}

/*--------------------------------------------------
  Main function
 *--------------------------------------------------*/
int main (void) {
	TOUCH_STATE  tsc_state;

  HAL_Init ();   /* Init Hardware Abstraction Layer */
  SystemClock_Config ();           /* Config Clocks */
  
	Touch_Initialize();  /* Touchscrn Controller Init */
  GLCD_Initialize();      /* Graphical Display Init */
  setDisplay();                /* Draw GLCD Display */
	
	while (1) {
    Touch_GetState (&tsc_state); /* Get touch state */
    
    if (tsc_state.pressed)
      updateDisplay(&tsc_state);
    else 
      clearDisplay();
    
   wait_delay(100);   	
	}
}
