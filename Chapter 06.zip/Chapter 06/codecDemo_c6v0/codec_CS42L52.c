/*--------------------------------------------------
 * Name:    Codec_CS42L52.c
 * Purpose: CS42L52 Audio Codec Driver
 * Note(s): 
 *--------------------------------------------------
 * Revision History
 * 07.2014 Ported orginal by Grant Ashton.
 * 11.09.2014 Bug Fixes. Tested MHF
 * 28.12.2015 Updated CMSIS 4.3.0
 *
 *
 * Mark Fisher CMP, UEA, Norwich 
 *--------------------------------------------------*/
#include "CS42L52.h"
#include "codec_CS42L52.h"
#include "stm32f4xx_hal.h"
#include "Driver_I2C.h"
#include "timer.h"

#ifndef CODEC_I2C_PORT
#define CODEC_I2C_PORT    1     /* I2C Port number  */
#endif

/* 7-bit I2C Address = 1001010b */
#define CODEC_I2C_ADDR    0x4A 

/* I2C Driver */
#define _I2C_Driver_(n)  Driver_I2C##n
#define  I2C_Driver_(n) _I2C_Driver_(n)
extern ARM_DRIVER_I2C    I2C_Driver_(CODEC_I2C_PORT);
#define ptrI2C         (&I2C_Driver_(CODEC_I2C_PORT))

/* Calculate array size */
#define ARR_SZ(x) (sizeof (x) / sizeof(x[0]))
  
#define delay_ms HAL_Delay

/* Register value */
typedef struct {
  uint8_t Addr;
  uint8_t Val;
} REG_VAL;


/***
* CODEC initialization based on p38
* of CS42L52 data sheet DS680F2
*****/
REG_VAL CODEC_Config_Init[] = { 	
  {0x00, 0x99},
  {0x3E, 0xBA},
  {0x47, 0x80},
  {0x32, 0x80},
  {0x32, 0x00},
  {0x00, 0x00},
};

/***
* CODEC initialization for Beep Generator
* of CS42L52 (Grant Ashton)
*****/
REG_VAL CODEC_Config_Beep[] ={
	/* Set I2S Ser. Mstr Op Only, for Beep Gen */
	{CS42L52_IFACE_CTL1, 0x80},
	/* Speaker Vol B=A, MONO */
	{CS42L52_PB_CTL2, 0x0A},
	/* Set master vol for A  */
	{CS42L52_MASTERA_VOL, 0xC0},
	/* Ignore jpr setting		 */
	{CS42L52_PWRCTL3, 0xAA}
};

/**
  \fn          static int32_t Codec Write (uint8_t reg, const uint8_t *val)
  \brief       Write value to Touchscreen controller register
  \param[in]   reg    Register address
  \param[in]   val    Pointer with data to write to register
  \returns
   - \b  0: function succeeded
   - \b -1: function failed
*/
static int32_t Codec_Write (uint8_t reg, uint8_t val) {
  uint8_t data[2];

  data[0] = reg;
  data[1] = val;

  ptrI2C->MasterTransmit (CODEC_I2C_ADDR, data, 2, false);
  while (ptrI2C->GetStatus().busy);
  if (ptrI2C->GetDataCount() != 2) return -1;

  return 0;
}

/**
  \fn          int32_t Codec_Read (uint8_t reg, uint8_t *val)
  \brief       Read register value from Audio Codec
  \param[in]   reg    Register address
  \param[out]  val    Pointer where data will be read from register
  \returns
   - \b  0: function succeeded
   - \b -1: function failed
*/
static int32_t Codec_Read (uint8_t reg, uint8_t *val) {
  uint8_t data[1];

  data[0] = reg;
  ptrI2C->MasterTransmit (CODEC_I2C_ADDR, data, 1, true);
  while (ptrI2C->GetStatus().busy);
  if (ptrI2C->GetDataCount() != 1) return -1;
  ptrI2C->MasterReceive (CODEC_I2C_ADDR, val, 1, false);
  while (ptrI2C->GetStatus().busy);
  if (ptrI2C->GetDataCount() != 1) return -1;

  return 0;
}


/**
  \fn     static void genMCLK(void)
  \brief  Generate the 12MHz clock required for
          Audio CODEC Master Clock (MCLK).
**/
static void genMCLK(void) {
  GPIO_InitTypeDef GPIO_InitStruct;
  
	TIM3_Initialize();
  __GPIOC_CLK_ENABLE();
	
   /* Configure GPIO pin: PC6 */
  GPIO_InitStruct.Pin   = GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull  = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FAST;
  GPIO_InitStruct.Alternate = GPIO_AF2_TIM3;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
}


/**
  \fn     static void configureCodec(void)
  \brief  Initialize and Configure the Audio Codec 
          via I2C interface
**/
static void configureCodec(void) {
	uint32_t i;
	
	Codec_Write(0x02, 0x01);	/* Keep Codec Power-down */  
  delay_ms(10);                         /* Wait 10ms */
	
	for (i = 0; i < ARR_SZ(CODEC_Config_Init); i++)
    Codec_Write (CODEC_Config_Init[i].Addr, CODEC_Config_Init[i].Val);

	for (i = 0; i < ARR_SZ(CODEC_Config_Beep); i++)
    Codec_Write (CODEC_Config_Beep[i].Addr, CODEC_Config_Beep[i].Val);
}


/**
	\fn     int32_t CodecInitialize(void)
	\brief  Initialize and Configure the Audio Codec
  \returns
   - \b  0: function succeeded
   - \b -1: function failed
*/
int32_t CodecInitialize(void) {
	int32_t status;
  
	/*
	* Configure I2C
	*/
	ptrI2C->Initialize    (NULL);
  ptrI2C->PowerControl  (ARM_POWER_FULL);
  ptrI2C->Control       (ARM_I2C_BUS_SPEED, ARM_I2C_BUS_SPEED_FAST);
  ptrI2C->Control       (ARM_I2C_BUS_CLEAR, 0);

	/* Configure CODEC */
	configureCodec();
	genMCLK();
	
	/* CODEC Power up	*/
	status = Codec_Write(CS42L52_PWRCTL1, 0x00); 
  delay_ms(10); /* Wait 10ms */
  
  return status;
}

/**
	\fn     int32_t readCodecChipID(uint8_t *val)
	\brief  Read Chip ID
  \param[out]  val    Pointer where data will be read from register
  \returns
   - \b  0: function succeeded
   - \b -1: function failed
*/
int32_t readCodecChipID(uint8_t *val) {
  int32_t status = Codec_Read(1, val);
  
  return status;
}


/**
	\fn 	  void Beep(noteInfo note)
  \brief  Generates a beep at the freqency defined by note.pitch 
          and for time defined by note.duration.
  \note   Values that can be used with this function for note
          and beep_duration are defined in codec_CS42L52.h
**/
void Beep(noteInfo note ) {
	Codec_Write(CS42L52_BEEP_VOL, 0x00);	/* Beep off time 1.23s
                                         	 and volume 0dB     */
	Codec_Write(CS42L52_BEEP_FREQ, note.pitch | note.duration);	
	                                      /* Set beep note and	*/ 																												/* beep duration								*/
	Codec_Write(CS42L52_BEEP_TONE_CTL, 0x40);	/* play sgl beep  */	
	Codec_Write(CS42L52_BEEP_TONE_CTL, 0x00);	/* Disable beep		*/
}


///**
//  \fn     void DecreaseVolume(void)
//  \brief  Decreases the volume by 0.5dB when called.
//**/
////void DecreaseVolume(void) {
////	int16_t currentVolume = getVolume();
////	const uint16_t minVolume = 0x19; /* -102db * 2 */

////	if (currentVolume != minVolume) { /* Check that vol is not at min */
////		currentVolume -= 1; //0.5dB decrement
////    setVolume(currentVolume);		
////	}
////}


///**
//  \fn     void IncreaseVolume(void)
//  \brief  Increase the volume by 0.5dB when called.
//**/
////void IncreaseVolume(void)
////{
////	int16_t currentVolume = getVolume();
////	const uint16_t maxVolume = 0x18; /* 12db in 0.5dB steps */
////	
////	if (currentVolume != maxVolume) { 
////		currentVolume += 1; /* 0.5dB increment */
////    setVolume(currentVolume);		
////	}
////}


///**
//  \fn     void setVolume(uint8_t volume)
//  \brief  Sets volume (-102dB to 12dB)
//**/
////void setVolume(uint8_t volume) {
////	Codec_Write(CS42L52_MASTERA_VOL, (uint8_t) volume);
////}


///**
//  \fn     int16_t getVolume(void)
//  \brief  read current volume
//**/
////int16_t getVolume(void)
////{
////	uint8_t currentVolume;
////  Codec_Read(CS42L52_MASTERA_VOL, &currentVolume);
////	
////	return currentVolume; 
////}


///**
//  \fn     void Mute(void)
//  \brief  set mute ON
//**/
////void Mute(void)
////{
////	Codec_Write(CS42L52_PB_CTL1, 0x01);	
////}


///**
//  \fn     void UnMute(void)
//  \brief  set mute OFF
//**/
//void UnMute(void)
////{
////	Codec_Write(CS42L52_PB_CTL1, 0x00);
////}

