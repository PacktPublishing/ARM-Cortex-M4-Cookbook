/*--------------------------------------------------
 * Recipe:  codecDemo_c6v0
 * Name:    codecDemo.c
 * Purpose: Test MCBSTM32F400 audio codec driver
 * Note(s): sets codec and outputs beep sound
 *--------------------------------------------------
 * Revision History
 * 07.2014 Created
 * 09.2014 Tested
 * 28.12.2015 Updated uVision5.17+DFP2.6.0
 *
 * Mark Fisher, CMP, UEA, Norwich.
 *--------------------------------------------------*/

#include "stm32f4xx_hal.h"
#include "cmsis_os.h"
#include "Driver_I2C.h"
#include "codec_CS42L52.h"
#include "CS42L52.h"
#include "GLCD_Config.h"
#include "Board_GLCD.h"
#include <stdio.h>

#define wait_delay HAL_Delay

/* Globals */
extern GLCD_FONT GLCD_Font_16x24;

/* Function Prototypes */
void SystemClock_Config(void);
void showStatus(int32_t stat);
void setDisplay(void);

#ifdef __RTX
extern uint32_t os_time;

uint32_t HAL_GetTick(void) {
  return os_time; 
}
#endif

/**
  * System Clock Configuration
  */
void SystemClock_Config(void) {
  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

  /* Enable Power Control clock */
  __HAL_RCC_PWR_CLK_ENABLE();

  /* The voltage scaling allows optimizing the power consumption when the
     device is clocked below the maximum system frequency (see datasheet). */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /* Enable HSE Oscillator and activate PLL with HSE as source */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  HAL_RCC_OscConfig(&RCC_OscInitStruct);

  /* Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2
     clocks dividers */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_PCLK1 |
                                RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5);
}


/*--------------------------------------------------
  setDisplay
 *--------------------------------------------------*/
void setDisplay( ) {
  GLCD_SetBackgroundColor (GLCD_COLOR_WHITE);
  GLCD_ClearScreen ();  /* clear the GLCD */
  
  GLCD_SetBackgroundColor (GLCD_COLOR_BLUE);
	GLCD_SetForegroundColor (GLCD_COLOR_WHITE);
  GLCD_SetFont (&GLCD_Font_16x24);
	GLCD_DrawString (0, 0*24, " CORTEX-M4 COOKBOOK ");
  GLCD_DrawString (0, 1*24, "  PACKT Publishing  ");
  
  GLCD_SetBackgroundColor (GLCD_COLOR_WHITE); 	
	GLCD_SetForegroundColor (GLCD_COLOR_BLACK);
}


void showStatus(int32_t stat) {
  if (stat==0) GLCD_DrawString (1*16, 8*24,"Codec OK  ");
	else GLCD_DrawString (1*16, 8*24,"Codec FAIL");
}


/*--------------------------------------------------
  Main function
 *--------------------------------------------------*/
int main (void) {
  noteInfo note = {G5, 0x02};
		
	uint8_t codecID;
  char buffer[128];
  
  HAL_Init ();   /* Init Hardware Abstraction Layer */
  SystemClock_Config ();           /* Config Clocks */
	
	GLCD_Initialize();
  setDisplay();
  
	showStatus(CodecInitialize()); 
  showStatus(readCodecChipID(&codecID));
	sprintf(buffer, "Chip ID: 0x%x", codecID);
	GLCD_DrawString (1*16, 9*24, buffer);

	while (1) {    
    Beep(note);	                   /* Play the note */  
    
    wait_delay(500);                       /* pause */
	} /* WHILE */
}
