/*-----------------------------------------------------------------------------
 * Name:    timer.h
 * Purpose: Timer definitions
 *-----------------------------------------------------------------------------
 * 
 * Mark Fisher, CMP, UEA, Norwich
 *----------------------------------------------------------------------------*/

#ifndef __TIMER_H
#define __TIMER_H

extern void     TIM3_Initialize     (void);

#endif /* __TIMER_H */
