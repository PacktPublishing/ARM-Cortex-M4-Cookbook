/*--------------------------------------------------
 * Recipe:  codecDemo_c6v1
 * Name:    audioCodecDemo.c
 * Purpose: MCBSTM32F400 audio codec demo example 
 * Note(s): plays tune
 *--------------------------------------------------
 * Revision History
 * 07.2014 Created
 * 09.2014 Tested
 * 28.12.2015 Updated uVision5.17+DFP2.6.0
 *
 * Mark Fisher, CMP, UEA, Norwich.
 *--------------------------------------------------*/

#include "stm32f4xx_hal.h"
#include "cmsis_os.h"
#include "codec_CS42L52.h"
#include "GLCD_Config.h"
#include "Board_GLCD.h"
#include "Board_Buttons.h"
#include "Board_LED.h"
#include <stdio.h>

/* Uncomment to display ChipID and status */
//#define __DEBUG 1

#define wait_delay HAL_Delay

/* Keys bit masks */
#define BUTTONS_USER_MASK   (1<<0)
#define BUTTONS_TAMPER_MASK (1<<1)
#define BUTTONS_WAKEUP_MASK (1<<2)

/* Calculate array size */
#define ARR_SZ(x) (sizeof (x) / sizeof(x[0]))

#define BEAT_TIME 500          /* Time between Beeps */


/* Globals */
extern GLCD_FONT GLCD_Font_16x24;
bool mute = false; /* Global 'mute' state */

noteInfo tune[] = {
  {G5, 0x02}, {G5, 0x02}, {A5, 0x02}, {F5, 0x04}, 
  {G5, 0x01}, {A5, 0x02}, {B5, 0x02}, {B5, 0x02}, 
  {C6, 0x02}, {B5, 0x04}, {A5, 0x01}, {G5, 0x02}, 
  {A5, 0x02}, {G5, 0x02}, {F5, 0x02}, {G5, 0x02}, 
  {G5, 0x01}, {A5, 0x01}, {B5, 0x01}, {C6, 0x01}, 
  {D6, 0x02}, {D6, 0x02}, {D6, 0x02}, {D6, 0x04}, 
  {C6, 0x01}, {B5, 0x02}, {C6, 0x02}, {C6, 0x02},
  {C6, 0x02}, {C6, 0x04}, {B5, 0x01}, {A5, 0x02}, 
  {B5, 0x02}, {C6, 0x01}, {B5, 0x01}, {A5, 0x01}, 
  {G5, 0x01}, {B5, 0x04}, {C6, 0x01}, {D6, 0x02}, 
  {E6, 0x01}, {C6, 0x01}, {B5, 0x02}, {A5, 0x02}, 
  {G5, 0x09} };

/* Function Prototypes */
void SystemClock_Config(void);

#ifdef __RTX
extern uint32_t os_time;

uint32_t HAL_GetTick(void) {
  return os_time; 
}
#endif

/**
  * System Clock Configuration
  */
void SystemClock_Config(void) {
  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

  /* Enable Power Control clock */
  __HAL_RCC_PWR_CLK_ENABLE();

  /* The voltage scaling allows optimizing the power consumption when the
     device is clocked below the maximum system frequency (see datasheet). */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /* Enable HSE Oscillator and activate PLL with HSE as source */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  HAL_RCC_OscConfig(&RCC_OscInitStruct);

  /* Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2
     clocks dividers */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_PCLK1 |
                                RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5);
}


/**
  \fn       void showCodecInfo(void)
  \brief    displays chipID and status
*/
void showCodecInfo( ) {
  char buffer[128];		
	uint32_t status;
  uint8_t codecValue;
  
  status = readCodecChipID(&codecValue);
	if (status==0) GLCD_DrawString (1*16, 8*24,"Codec OK  ");
	else GLCD_DrawString (1*16, 8*24,"Codec FAIL");
	sprintf(buffer, "Chip ID: 0x%x", codecValue);
	GLCD_DrawString (1*16, 9*24, buffer);
}

/**
  \fn       void SetDisplay(void)
  \brief    sets GLCD for this recipe
*/
void setDisplay( ) {
  
  GLCD_SetBackgroundColor (GLCD_COLOR_WHITE);
  GLCD_ClearScreen ();
  GLCD_SetFont (&GLCD_Font_16x24);
  GLCD_SetForegroundColor (GLCD_COLOR_BLACK);
  GLCD_DrawString (1*16, 1*24, "Volume: ");
	GLCD_DrawString (1*16, 5*24, "Wakeup toggles MUTE");
  GLCD_DrawString (1*16, 6*24, "User and Tamper");
	GLCD_DrawString (1*16, 7*24, "Adjust Volume");
 
  #ifdef __DEBUG  
  showCodecInfo( );
  #endif
}


/**
  \fn       void VolumeUserInput(void)
  \brief    Checks for user input on buttons
*/
void volumeUserInput( ) {
  uint32_t keyMsk;
  
	keyMsk = Buttons_GetState (); 
	if (keyMsk & BUTTONS_TAMPER_MASK) 
		increaseVolume(10);
	else {
		if ( keyMsk & BUTTONS_USER_MASK ) 
			decreaseVolume(10);
		else
			if (keyMsk & BUTTONS_WAKEUP_MASK) { 
        mute = !mute;
        setMute(mute);
		} /* IF-ELSE */
	} /* IF-ELSE */
}


/**
  \fn       void ShowVolumeGraph(void)
  \brief    draws volume bargraph
*/
void showVolumeGraph( ) {

	if (mute) {/* If codec is muted, display red graph */
    GLCD_SetForegroundColor (GLCD_COLOR_RED);
    GLCD_DrawString(1*16, 2*24, "(Muted)");
  }
  else {                        /* else blue graph */
    GLCD_SetForegroundColor (GLCD_COLOR_BLUE);
    GLCD_DrawString(1*16, 2*24, "       ");
  }
	GLCD_DrawBargraph(130, 24, 180, 20, (getVolume()- (MIN_VOL_DB*2))/2);
}


/*--------------------------------------------------
  Main function
 *--------------------------------------------------*/
int main (void) {

	uint32_t i = 0;
	uint32_t beepTimeOut = 0;
 
  HAL_Init ();   /* Init Hardware Abstraction Layer */
  SystemClock_Config ();           /* Config Clocks */
	
	GLCD_Initialize();
	LED_Initialize ();
	Buttons_Initialize ();
	CodecInitialize();    	
  setDisplay( );  

	while (1) {  
    if (!beepTimeOut) {
      Beep(tune[i]);	        /* Play the next note */      
      beepTimeOut = tune[i].duration;
      i = (i+1)%ARR_SZ(tune);
    }
    else
      beepTimeOut--; /* Wait */
    
    volumeUserInput( );
    showVolumeGraph( );
    LED_SetOut(i);
    
    wait_delay(BEAT_TIME);
	} /* WHILE */
}
