/*--------------------------------------------------------------
 * Name:    timer.c
 * Purpose: Low level timer functions
 *--------------------------------------------------------------
 * This file was developed from an original by Keil.
 *
 * Modification History
 * 16.04.14 created
 *
 * Mark Fisher, CMP, UEA, Norwich
 *------------------------------------------------------------*/

#include "stm32f4xx.h"               /* STM32F4xx Definitions */
#include "timer.h"

/**************************************************************
 * TIM3_Initialize ( )
 **************************************************************
 * Initializes TIM3 generates 12MHz. clock (~50% duty cycle)
 * SystemCoreClock = 168 MHz - set by SystemInit ( )
 * Refer to Figure 134 of STM Reference Manual RM0090
 * TIMxCLK = SystemCoreClock/2
 * Hence ticks = 168,000,000 / 12,000,000 * 2 = 7
 * Prescaler = Default; ARR = 7;
 ***************************************************************/
void TIM3_Initialize (void) {
	const uint16_t ARR_val = 7;
	
	RCC->APB1ENR |= RCC_APB1ENR_TIM3EN; /* enable clock for TIM3 */

	TIM3->CCMR1 = 0x00000070;	/* Set PWM Mode 2									 */
  TIM3->ARR = ARR_val - 1;            /* set auto-reload       */
	TIM3->CCR1 = 3; /* Capture/Compare, Duty cycle (~50%)				 */
	TIM3->CCER = 0x00000001; 	/* En capture/compare on Chan 1		 */
	TIM3->CR1 = 0x00000001;		/* Enable counter									 */	
}	
