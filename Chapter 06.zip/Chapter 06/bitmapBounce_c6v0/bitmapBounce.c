/*--------------------------------------------------
 * Recipe:  bitmapBounce_c6v0
 * Name:    bitmapBounce.c
 * Purpose: demo example using bitmaps
 *--------------------------------------------------
 *
 * Modification History
 * 06.02.14 Created
 * 31.12.15 Updated uVision5.17 + DFP2.6.0
 *
 * Dr Mark Fisher, CMP, UEA, Norwich, UK
 *--------------------------------------------------*/

#include "stm32f4xx_hal.h"
#include "GLCD_Config.h"
#include "Board_GLCD.h"

#define wait_delay HAL_Delay

/* Globals */
//extern GLCD_FONT     GLCD_Font_16x24;

/* GIMP RGB C-Source image dump (ball_16bit.c) */
static const struct {
  unsigned int 	 width;
  unsigned int 	 height;
  unsigned int 	 bytes_per_pixel; /* 2:RGB16, 3:RGB, 4:RGBA */ 
  unsigned char	 pixel_data[16 * 24 * 2 + 1];
} gimp_image = {
  16, 24, 2,
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377\377\0\370\0\370\0\370\0\370\377\377"
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\0\370\0\370\0\370\0\370\0\370\0\370\0\370"
  "\0\370\0\370\0\370\377\377\377\377\377\377\377\377\377\377\0\370\0\370\0"
  "\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\377\377\377\377"
  "\377\377\377\377\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0"
  "\370\0\370\0\370\377\377\377\377\377\377\0\370\0\370\0\370\0\370\0\370\0"
  "\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\377\377\377\377\0\370"
  "\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370\0\370"
  "\0\370\377\377\377\377\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"
  "\0\0\0\377\377\377\377\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0"
  "\37\0\37\0\37\0\37\0\377\377\377\377\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37"
  "\0\37\0\37\0\37\0\37\0\37\0\37\0\377\377\377\377\377\377\37\0\37\0\37\0\37"
  "\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\377\377\377\377\377\377\377\377"
  "\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\377\377\377"
  "\377\377\377\377\377\377\377\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0\37\0"
  "\37\0\377\377\377\377\377\377\377\377\377\377\377\377\377\377\37\0\37\0\37"
  "\0\37\0\37\0\37\0\37\0\37\0\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\37\0\37\0\37\0\37\0\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377"
  "\377\377\377\377\377\377\377\377\377",
};


#ifdef __RTX
extern uint32_t os_time;

uint32_t HAL_GetTick(void) {
  return os_time; 
}
#endif

/* Function Prototypes */
void SystemClock_Config(void);

/**
  * System Clock Configuration
  */
void SystemClock_Config(void) {
  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

  /* Enable Power Control clock */
  __HAL_RCC_PWR_CLK_ENABLE();

  /* The voltage scaling allows optimizing the power consumption when the
     device is clocked below the maximum system frequency (see datasheet). */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /* Enable HSE Oscillator and activate PLL with HSE as source */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  HAL_RCC_OscConfig(&RCC_OscInitStruct);

  /* Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2
     clocks dividers */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_PCLK1 |
                                RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5);
}

/**
  * Main function
  */
int main (void) {
	uint32_t dirn = 1;
  /* initial ball position */
	uint32_t x = (GLCD_WIDTH-gimp_image.width)/2; 
  uint32_t y = (GLCD_HEIGHT-gimp_image.height)/2;					
	const uint32_t num_ticks = 5;
	
  HAL_Init ( );
  SystemClock_Config ( );
  
	GLCD_Initialize();					     
  GLCD_SetBackgroundColor (GLCD_COLOR_WHITE);
  GLCD_ClearScreen (); 
	GLCD_SetForegroundColor (GLCD_COLOR_BLUE);
  GLCD_DrawBitmap ( x, y, gimp_image.width, gimp_image.height, gimp_image.pixel_data);

	for (;;) {					                 /* superloop */
		wait_delay(num_ticks);	/* update ball position */
		switch (dirn) {
			case 0: x++;
					    break;
			case 1: x++;
					    y--;
					    break;
			case 2: y--;
              break;
			case 3: x--;
					    y--;
					    break;
			case 4: x--;
					    break;
			case 5: x--;
					    y++;
					    break;
			case 6: y++;
					    break;
			case 7: x++;
					    y++;			
		}
		if ((x==0) || x==(GLCD_WIDTH-gimp_image.width) ) {  /* check collision with */
			switch (dirn)                      /* vertical screen edge */
				{
				case 0: dirn = (dirn+4)%8;
							  break;
				case 1: dirn = (dirn+2)%8;
						    break;
				case 3: dirn = (dirn+6)%8;
						    break;
				case 4: dirn = (dirn+4)%8;
						    break;
				case 5: dirn = (dirn+2)%8;
						    break;
				case 7: dirn = (dirn+6)%8;
						    break;
				}
		}
		if ((y==0) || y==(GLCD_HEIGHT-gimp_image.height) ) { /* check collision with */
			switch (dirn)                      /* horizontal screen edge */
				{
				case 1: dirn = (dirn+6)%8;
						    break;
				case 2: dirn = (dirn+4)%8;
						    break;
				case 3: dirn = (dirn+2)%8;
						    break;
				case 5: dirn = (dirn+6)%8;
						    break;
				case 6: dirn = (dirn+4)%8;
						    break;
				case 7: dirn = (dirn+2)%8;
						    break;
				}
		}
    GLCD_DrawBitmap ( x, y, gimp_image.width, gimp_image.height, (unsigned char *) gimp_image.pixel_data);

  } /* end for */
}



