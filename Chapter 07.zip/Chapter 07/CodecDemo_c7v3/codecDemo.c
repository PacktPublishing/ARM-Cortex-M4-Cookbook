/*--------------------------------------------------
 * Recipe:  codecDemo_c7v3
 * Name:    codecDemo.c
 * Purpose: Demo example for MCBSTM32F400 using
 *          Interrupts
 * Note(s): Filter Demo @22 kHz sample freq.
 *          Note: Mixes Low Pass and High Pass filter samples
 *--------------------------------------------------
 * Revision History
 * 09.2014 Created
 * 01.2016 Updated CMSIS 4.3.0 & STM32CUBE_HAL 1.4.0
 *
 * Mark Fisher, CMP, UEA, Norwich.
 *--------------------------------------------------*/

#include "stm32f4xx_hal.h"
#include "cmsis_os.h"
#include "codec_CS42L52.h"
#include "GLCD_Config.h"
#include "Board_GLCD.h"
#include "Board_ADC.h"
#include "Custom_ADC.h"
#include "Board_LED.h"
#include "CS42L52.h"
#include "I2S_audio.h"
#include "stm32f4xx_hal_i2s.h"
#include <stdio.h>

/* Uncomment to display ChipID and status */
#define __DEBUG 1

#define wait_delay HAL_Delay
#define I2S_TX_TIMEOUT_VALUE ((uint32_t)100) /* Timeout value fixed to 100 ms */
#define NTAPS 7  /* number of filter taps */
#define FRAME_SIZE 5

/* Macro to calculate array size */
#define ARR_SZ(x) (sizeof (x) / sizeof(x[0]))


/* Global External Vars */
extern GLCD_FONT GLCD_Font_16x24;
extern I2S_HandleTypeDef hi2s;
						                  
const   int16_t data [] =   { 0,  0,  0,  0, 0, 
							                0,  0,  0,  0, 0,
				                      1,  1,  1,  1, 1, 
						                  1,  1,  1,  1, 1  };

uint16_t sample = 0;
bool flag = false;
int32_t adcValue;                           
float sFactor = 0.0;
const float c = 255.0;                              
                           
                             
#ifdef __RTX
extern uint32_t os_time;

uint32_t HAL_GetTick(void) {
  return os_time; 
}
#endif

/**
  * System Clock Configuration
  */
void SystemClock_Config(void) {
  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

  /* Enable Power Control clock */
  __HAL_RCC_PWR_CLK_ENABLE();

  /* The voltage scaling allows optimizing the power consumption when the
     device is clocked below the maximum system frequency (see datasheet). */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /* Enable HSE Oscillator and activate PLL with HSE as source */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  HAL_RCC_OscConfig(&RCC_OscInitStruct);

  /* Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2
     clocks dividers */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_PCLK1 |
                                RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5);
} 

/*---------------------------------------------------------
 * Filter
 *-------------------------------------------------------*/
uint16_t filter(int16_t inSmpl) {
  static const uint8_t nTaps = 21; 
	/* Filter Coefficients */ 
  static const float lpfiltCoef[] = {    0.0,  0.0184,  0.0215,  0.0277,  0.0368,  0.0480,  0.0602,  0.0720,
                                      0.0818,  0.0882,  0.0905,  0.0882,  0.0818,  0.0720,  0.0602,  0.0480, 
                                      0.0368,  0.0277,  0.0215,  0.0184,     0.0 }; 
  static const float hpfiltCoef[] = { 0.0511,  0.0540,  0.0524,  0.0533,  0.0528,  0.0517,  0.0493,  0.0450,
                                      0.0363,     0.0,  0.1000,  0.0637,  0.0550,  0.0507,  0.0483,  0.0472,
                                      0.0467,  0.0476,  0.0460,  0.0489,     0.0 };  
  static float smplBuff[] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                              0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 
                              0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
  static uint8_t idx = 0;
	float lpVal = 0.0, hpVal = 0.0, outVal = 0.0;
  uint8_t coefIdx, newIdx;
  static const float int16max = (float) INT16_MAX;                           
                            
  /* update buffer */
  newIdx = (nTaps-1-idx);
  smplBuff[newIdx] = (float) inSmpl;
	/* do convolution */
	for (coefIdx = 0; coefIdx<nTaps; coefIdx++) {
	  lpVal += lpfiltCoef[coefIdx] * smplBuff[(newIdx+coefIdx)%nTaps]; 
    hpVal += hpfiltCoef[coefIdx] * smplBuff[(newIdx+coefIdx)%nTaps];    
  } 
  /* outVal is weighted sum of low pass and high pass filter signal*/
  outVal = (int16_t) ( (lpVal*sFactor +  hpVal*((float)1.0-sFactor)) * int16max);

  /* update idx */
  idx = (idx+1)%nTaps;
  
  return (uint16_t) outVal;
}	
								
  
/*--------------------------------------------------
 * Codec IRQ Handler
 *--------------------------------------------------*/		 
void SPI2_IRQHandler(void) {

  if (flag) LED_On(0);
  else
    LED_Off(0);    
  /* Transmit data */
  hi2s.Instance->DR = sample;
  flag = true;
  
}

/*--------------------------------------------------
 * ADC IRQ Handler
 *--------------------------------------------------*/
void ADC_IRQHandler (void) {
	
  ADC3->SR &= ~2;       /* Clear EOC interrupt flag */
  adcValue = (ADC3->DR)>> 4;     /* Get converted value */
  ADC3->CR2 |= (1 << 30);  /* Start next conversion */
			
}

/**
  \fn       void showCodecI2SInfo(void)
  \brief    displays I2S State and status
*/
void showCodecI2SInfo (HAL_StatusTypeDef status) {
     if (status == HAL_OK) 
      GLCD_DrawString (1*16, 8*24,"Codec OK      ");
    else {
      GLCD_DrawString (1*16, 8*24,"Codec I2S FAIL");
      while (1) {
        /* trap */;
      }
    }
  
  if (hi2s.State == HAL_I2S_STATE_READY) 
    GLCD_DrawString (1*16, 8*24,"Codec READY   ");
  else {
    GLCD_DrawString (1*16, 8*24,"Codec I2S FAIL");
    while (1) {
      /* trap */;
    }
  }
}
  
  
/**
  \fn       void showCodecI2CInfo(void)
  \brief    displays chipID and status
*/
void showCodecI2CInfo( ) {
  char buffer[128];		
	uint32_t status;
  uint8_t codecValue;
  
  status = readCodecChipID(&codecValue);
	if (status==0) GLCD_DrawString (1*16, 8*24,"Codec OK      ");
	else {
    GLCD_DrawString (1*16, 8*24,"Codec I2C FAIL");
    while (1){
      /* trap */ ; 
    }
  }
	sprintf(buffer, "Chip ID: 0x%x", codecValue);
	GLCD_DrawString (1*16, 9*24, buffer);
}

/**
  \fn       void SetDisplay(void)
  \brief    sets GLCD for this recipe
*/
void setDisplay( ) {
  
  GLCD_SetBackgroundColor (GLCD_COLOR_WHITE);
  GLCD_ClearScreen ();  
  GLCD_SetBackgroundColor (GLCD_COLOR_BLUE);
	GLCD_SetForegroundColor (GLCD_COLOR_WHITE);
  GLCD_SetFont (&GLCD_Font_16x24);
	GLCD_DrawString (0, 0*24, " CORTEX-M4 COOKBOOK ");
  GLCD_DrawString (0, 1*24, "  PACKT Publishing  ");
	GLCD_SetBackgroundColor (GLCD_COLOR_WHITE); 	
	GLCD_SetForegroundColor (GLCD_COLOR_BLUE);
	GLCD_DrawString(0,4*24,"Basic I2S Codec Demo");
  GLCD_DrawString(0,5*24,"   using interupts  ");
 
  #ifdef __DEBUG  
  showCodecI2CInfo( );
  #endif
}


/*--------------------------------------------------
  Main function
 *--------------------------------------------------*/
int main (void) {
  noteInfo note = {G5, 0x02};
  codecMode mode = AUDIO_SAMPLED;
  HAL_StatusTypeDef status;
  uint8_t i = 0;
  bool rightSmpl;
  const uint8_t sz = ARR_SZ(data);
  
  /* Uncomment for BEEP */
  //mode = AUDIO_BEEP;
  
  HAL_Init( );
  SystemClock_Config( );

  LED_Initialize();
  ADC_Initialize_and_Set_IRQ ();/* ADC Special Init */
	GLCD_Initialize();
 	status = CodecInitialize(mode);
  
  setDisplay( );
  
  #ifdef __DEBUG
  if (mode == AUDIO_SAMPLED) 
    showCodecI2SInfo(status);
  #endif

  /* Enable I2S peripheral */
  __HAL_I2S_ENABLE(&hi2s);
  
  /* Enable I2S Interrupts */
  __HAL_I2S_ENABLE_IT(&hi2s, (I2S_IT_TXE | I2S_IT_ERR));
  
	while (1) {
    if (mode == AUDIO_BEEP) {
      Beep(note);	                 /* Play the note */  
      wait_delay(500);                     /* pause */
    }
    else {
      if (flag) {
        rightSmpl = i%2; 
        if (!rightSmpl)               /* run filter */
          sample = filter(data[i>>1]);
        else                  /* update scalefactor */
          sFactor = ( (float) adcValue ) / c;
        
        i++;
        i %= (sz<<1);                   /* MOD 2*sz */
        flag = false;
      } 
    }

	} /* WHILE */
}
