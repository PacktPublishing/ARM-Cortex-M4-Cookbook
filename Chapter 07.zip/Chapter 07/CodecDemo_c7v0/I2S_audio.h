#ifndef __TEST_SPI_H
#define __TEST_SPI_H

//#include <stdint.h>

HAL_StatusTypeDef I2S_Audio_Initialize(void);
//void SPI_Send(const uint8_t outByte);

#endif
