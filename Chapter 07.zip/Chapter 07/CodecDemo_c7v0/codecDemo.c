/*--------------------------------------------------
 * Recipe:  codecDemo_c7v0
 * Name:    codecDemo.c
 * Purpose: Demo example for MCBSTM32F400
 * Note(s): Sinusoid Wave Demo @44 kHz sample freq
 *--------------------------------------------------
 * Revision History
 * 09.2014 Created
 * 02.01.2015 Updated CMSIS 4.3.0
 *
 * Mark Fisher, CMP, UEA, Norwich.
 *--------------------------------------------------*/

#include "stm32f4xx_hal.h"
#include "cmsis_os.h"
#include "codec_CS42L52.h"
#include "GLCD_Config.h"
#include "Board_GLCD.h"
#include "CS42L52.h"
#include "I2S_audio.h"
#include "stm32f4xx_hal_i2s.h"
#include <stdio.h>

/* Uncomment to display ChipID and status */
#define __DEBUG 1

#define wait_delay HAL_Delay
#define I2S_TX_TIMEOUT_VALUE ((uint32_t)100) /* Timeout value fixed to 100 ms */

/* Macro to calculate array size */
#define ARR_SZ(x) (sizeof (x) / sizeof(x[0]))


/* Global External Vars */
extern GLCD_FONT GLCD_Font_16x24;
extern I2S_HandleTypeDef hi2s;

/* 20 left+right channel samples @ 22kHz ~= 1.4 kHz. */
const int16_t dacLUT [] = {       0,       0,    9830,    9830,  19660,  19660,  26214,  26214,  31456,  31456,
							                32767,   32767,   31456,   31456,  26214,  26214,  19660,  19660,   9830,   9830,
				                          0,       0,   -9830,   -9830, -19661, -19661, -26214, -26214, -31457, -31457, 
						                 -32768,  -32768,  -31457,  -31457, -26214, -26214, -19661, -19661,  -9830,  -9830  };                         

#ifdef __RTX
extern uint32_t os_time;

uint32_t HAL_GetTick(void) {
  return os_time; 
}
#endif

/**
  * System Clock Configuration
  */
void SystemClock_Config(void) {
  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

  /* Enable Power Control clock */
  __HAL_RCC_PWR_CLK_ENABLE();

  /* The voltage scaling allows optimizing the power consumption when the
     device is clocked below the maximum system frequency (see datasheet). */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /* Enable HSE Oscillator and activate PLL with HSE as source */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  HAL_RCC_OscConfig(&RCC_OscInitStruct);

  /* Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2
     clocks dividers */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_PCLK1 |
                                RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5);
}                         
   
/**
  \fn       void showCodecI2SInfo(void)
  \brief    displays I2S State and status
*/
void showCodecI2SInfo (HAL_StatusTypeDef status) {
     if (status == HAL_OK) 
      GLCD_DrawString (1*16, 8*24,"Codec OK      ");
    else {
      GLCD_DrawString (1*16, 8*24,"Codec I2S FAIL");
      while (1) {
        /* trap */;
      }
    }
  
  if (hi2s.State == HAL_I2S_STATE_READY) 
    GLCD_DrawString (1*16, 8*24,"Codec READY   ");
  else {
    GLCD_DrawString (1*16, 8*24,"Codec I2S FAIL");
    while (1) {
      /* trap */;
    }
  }
}
  
  
/**
  \fn       void showCodecI2CInfo(void)
  \brief    displays chipID and status
*/
void showCodecI2CInfo( ) {
  char buffer[128];		
	uint32_t status;
  uint8_t codecValue;
  
  status = readCodecChipID(&codecValue);
	if (status==0) GLCD_DrawString (1*16, 8*24,"Codec OK      ");
	else {
    GLCD_DrawString (1*16, 8*24,"Codec I2C FAIL");
    while (1){
      /* trap */ ; 
    }
  }
	sprintf(buffer, "Chip ID: 0x%x", codecValue);
	GLCD_DrawString (1*16, 9*24, buffer);
}

/**
  \fn       void SetDisplay(void)
  \brief    sets GLCD for this recipe
*/
void setDisplay( ) {
  
  GLCD_SetBackgroundColor (GLCD_COLOR_WHITE);
  GLCD_ClearScreen ();  
  GLCD_SetBackgroundColor (GLCD_COLOR_BLUE);
	GLCD_SetForegroundColor (GLCD_COLOR_WHITE);
  GLCD_SetFont (&GLCD_Font_16x24);
	GLCD_DrawString (0, 0*24, " CORTEX-M4 COOKBOOK ");
  GLCD_DrawString (0, 1*24, "  PACKT Publishing  ");
	GLCD_SetBackgroundColor (GLCD_COLOR_WHITE); 	
	GLCD_SetForegroundColor (GLCD_COLOR_BLUE);
	GLCD_DrawString(0,4*24,"Basic I2S Codec Demo");
 
  #ifdef __DEBUG  
  showCodecI2CInfo( );
  #endif
}


/*--------------------------------------------------
  Main function
 *--------------------------------------------------*/
int main (void) {
  noteInfo note = {G5, 0x02};
  codecMode mode = AUDIO_SAMPLED;
  HAL_StatusTypeDef status;
  
  /* Uncomment for BEEP */
  //mode = AUDIO_BEEP;
  
  HAL_Init( );
  SystemClock_Config( );

	GLCD_Initialize();
 	status = CodecInitialize(mode);
  
  setDisplay( );
  
  #ifdef __DEBUG
  if (mode == AUDIO_SAMPLED) 
    showCodecI2SInfo(status);
  #endif
  
  

	while (1) {
    if (mode == AUDIO_BEEP) {
      Beep(note);	                 /* Play the note */  
      wait_delay(500);                     /* pause */
    }
    else
      HAL_I2S_Transmit(&hi2s, (uint16_t *) dacLUT, 
               ARR_SZ(dacLUT), I2S_TX_TIMEOUT_VALUE );
        
	} /* WHILE */
}
