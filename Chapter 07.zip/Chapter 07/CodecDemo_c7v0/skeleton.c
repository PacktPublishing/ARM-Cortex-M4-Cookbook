/*--------------------------------------------------------------
  Main function
 *------------------------------------------------------------*/
int main (void) {

	uint8_t codecValue;
  char buffer[128];		
	bool status;
	
	GLCD_Initialize();
	CodecInitialize();
	
	GLCD_Clear(White);
	GLCD_DisplayString(5,1,1,"CORTEX-M4 COOKBOOK");
	GLCD_DisplayString(6,1,1,"PACKT Publishing");
	GLCD_DisplayString(7,1,1,"Basic I2S Codec Demo");
	
	status = Codec_Read(1, &codecValue);
	if (status) GLCD_DisplayString(8,1,1,"Codec OK  ");
	else GLCD_DisplayString(8,1,1,"Codec FAIL");
	sprintf(buffer, "Chip ID: 0x%x", codecValue);
	GLCD_DisplayString(9,1,1, buffer);

	while (1) {		
		
	} /* WHILE */
}