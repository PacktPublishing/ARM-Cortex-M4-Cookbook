/*-----------------------------------------------------------------------------
 * Name:    CS42L52.h
 * Purpose: CS42L52 (Codec) register definitions
 *-----------------------------------------------------------------------------
 * This file is part of the uVision/ARM development tools.
 * This software may only be used under the terms of a valid, current,
 * end user licence from KEIL for a compatible version of KEIL software
 * development tools. Nothing else gives you the right to use this software.
 *
 * This software is supplied "AS IS" without warranties of any kind.
 *
 * Copyright (c) 2004-2013 KEIL - An ARM Company. All rights reserved.
 *----------------------------------------------------------------------------*/

#ifndef __CS42L52_H
#define __CS42L52_H

/* Register addresses */
#define CS42L52_CHIP_ID					0x01
#define CS42L52_PWRCTL1 				0x02
#define CS42L52_PWRCTL2					0x03
#define CS42L52_PWRCTL3					0x04
#define CS42L52_CLK_CTL					0x05
#define CS42L52_IFACE_CTL1			0x06
#define CS42L52_IFACE_CTL2			0x07
#define CS42L52_ADC_PGA_A				0x08
#define CS42L52_ADC_PGA_B				0x09
#define CS42L52_ANALOG_HPF_CTL	0x0A
#define CS42L52_ADC_HPF_FREQ		0x0B
#define CS42L52_ADC_MISC_CTL		0x0C
#define CS42L52_PB_CTL1					0x0D
#define CS42L52_MISC_CTL				0x0E
#define CS42L52_PB_CTL2					0x0F
#define CS42L52_MICA_CTL				0x10
#define CS42L52_MICB_CTL				0x11
#define CS42L52_PGAA_CTL				0x12
#define CS42L52_PGAB_CTL				0x13
#define CS42L52_PASSTHRUA_VOL		0x14
#define CS42L52_PASSTHRUB_VOL		0x15
#define CS42L52_ADCA_VOL				0x16
#define CS42L52_ADCB_VOL				0x17
#define CS42L52_ADCA_MIXER_VOL	0x18
#define CS42L52_ADCB_MIXER_VOL	0x19
#define CS42L52_PCMA_MIXER_VOL	0x1A
#define CS42L52_PCMB_MIXER_VOL	0x1B
#define CS42L52_BEEP_FREQ				0x1C
#define CS42L52_BEEP_VOL				0x1D
#define CS42L52_BEEP_TONE_CTL		0x1E
#define CS42L52_TONE_CTL				0x1F
#define CS42L52_MASTERA_VOL			0x20
#define CS42L52_MASTERB_VOL			0x21
#define CS42L52_HPA_VOL					0x22
#define CS42L52_HPB_VOL					0x23
#define CS42L52_SPKA_VOL				0x24
#define CS42L52_SPKB_VOL				0x25
#define CS42L52_ADC_PCM_MIXER		0x26
#define CS42L52_LIMITER_CTL1		0x27
#define CS42L52_LIMITER_CTL2		0x28
#define CS42L52_LIMITER_AT_RATE	0x29
#define CS42L52_ALC_CTL					0x2A
#define CS42L52_ALC_RATE				0x2B
#define CS42L52_ALC_THRESHOLD		0x2C
#define CS42L52_NOISE_GATE_CTL	0x2D
#define CS42L52_CLK_STATUS			0x2E
#define CS42L52_BATT_COMPEN			0x2F
#define CS42L52_BATT_LEVEL			0x30
#define CS42L52_SPK_STATUS			0x31
#define CS42L52_TEM_CTL					0x32
#define CS42L52_THE_FOLDBACK		0x33
#define CS42L52_CHARGE_PUMP			0x34

#endif /* __CS42L52_H */
