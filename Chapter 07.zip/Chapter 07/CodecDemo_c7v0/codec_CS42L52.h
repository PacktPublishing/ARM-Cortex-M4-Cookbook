/*--------------------------------------------------
 * Name:    codec_CS42L52.h
 * Purpose: CS42L52 Audio Codec Driver
 * Note(s):
 *--------------------------------------------------
 * Revision History
 * 07.2014 Created
 *
 *
 * Mark Fisher CMP, UEA, Norwich.
 *--------------------------------------------------*/
#ifndef _CODEC_H
#define _CODEC_H

#include <stdint.h>
#include <stdbool.h>
#include "stm32f4xx_hal_def.h"


// Volume constants
#define MIN_VOL_DB -102
#define MAX_VOL_DB +12

// Beep note frequency
#define A5 0x60
#define A6 0xD0
#define B5 0x70
#define B6 0xE0
#define C4 0x00
#define C5 0x10
#define C6 0x80
#define C7 0xF0
#define D5 0x20
#define D6 0x90
#define E5 0x30
#define E6 0xA0
#define F5 0x40
#define F6 0xB0
#define G5 0x50
#define G6 0xC0

//Beep on duration
#define TENTH_SECOND 0x00
#define HALF_SECOND 0x01
#define ONE_SECOND 0x02
#define TWO_SECOND 0x06
#define THREE_SECOND 0x09
#define FOUR_SECOND 0x0C
#define FIVE_SECOND 0x0F

/* Note value */
typedef struct {
  uint8_t pitch;
  uint8_t duration;
} noteInfo;

typedef enum {
  AUDIO_BEEP,
  AUDIO_SAMPLED
} codecMode;

HAL_StatusTypeDef CodecInitialize(codecMode mode);
int32_t readCodecChipID(uint8_t *val);
void Beep(noteInfo note);
void increaseVolume(uint32_t stepSize);
void decreaseVolume(uint32_t stepSize);
int32_t getVolume(void);
void setMute(bool state);




#endif
