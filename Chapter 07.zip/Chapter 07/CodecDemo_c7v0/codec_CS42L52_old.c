/*----------------------------------------------------------------------------
 * Name:    Codec_CS42L52.c
 * Purpose: CS42L52 Audio Codec Driver
 * Note(s): I2C Address = 1001010b
 *----------------------------------------------------------------------------
 * Revision History
 * 07.2014 Created
 * 11.092014 Bug Fixes. Tested MHF
 *
 *
 * Copyright (c) Mark Fisher & Grant Ashton, CMP, UEA, Norwich.
 *----------------------------------------------------------------------------*/
#include <stdint.h>
#include "cmsis_os.h"
#include "CS42L52.h"
#include "codec_CS42L52.h"
#include "stm32f4xx.h"
#include "Driver_I2C.h"
#include "timer.h"
#include "GPIO_STM32F4xx.h"
#include "I2S_audio.h"

#ifndef CODEC_I2C_PORT
#define CODEC_I2C_PORT    1               /* I2C Port number  */
#endif

#define CODEC_I2C_ADDR    0x4A          	/* 7-bit audio codec I2C address      */

/* I2C Driver */
#define _I2C_Driver_(n)  Driver_I2C##n
#define  I2C_Driver_(n) _I2C_Driver_(n)
extern ARM_DRIVER_I2C    I2C_Driver_(CODEC_I2C_PORT);
#define ptrI2C         (&I2C_Driver_(CODEC_I2C_PORT))

/* Calculate array size */
#define ARR_SZ(x) (sizeof (x) / sizeof(x[0]))

/* Register value */
typedef struct {
  uint8_t Addr;
  uint8_t Val;
} REG_VAL;


/***
* CODEC initialization based on p38
* of CS42L52 data sheet DS680F2
*****/
REG_VAL CODEC_Config_Init[] = { 	
  {0x00, 0x99},
  {0x3E, 0xBA},
  {0x47, 0x80},
  {0x32, 0x80},
  {0x32, 0x00},
  {0x00, 0x00},
};

/***
* CODEC initialization for 
* CS42L52 Beep Generator
*****/
REG_VAL CODEC_Config_Beep[] ={
	/****
	*Configure I2S Interface as Master
	******/
	{CS42L52_IFACE_CTL1, 0x80},
	/* Speaker Vol B=A, MONO */
	{CS42L52_PB_CTL2, 0x0A},
	/* Set master vol for A  */
	{CS42L52_MASTERA_VOL, 0xC0},
	/* Ignore jpr setting	(speaker always ON)	*/
	{CS42L52_PWRCTL3, 0xAA}
};

/***
* CODEC initialization for 
* CS42L52 Digital Audio
*****/
REG_VAL CODEC_Audio_I2S_Slave[] ={
	
	/****
	*Configure I2S Interface as Slave, 16bits
	******/
	{CS42L52_IFACE_CTL1, 0x03},  
	/* SDOUT is HI-Z */
  {CS42L52_IFACE_CTL2, 0x10},
	/* Speaker Vol B=A, MONO */
	{CS42L52_PB_CTL2, 0x0A},
	/* Set master vol for A/B */
	{CS42L52_MASTERA_VOL, 0xC0},
	/* Ignore jpr setting	(speaker always ON)	*/
	{CS42L52_PWRCTL3, 0xAA} 
};


/*-----------------------------------------------------------------------------
 *  		Codec_Write:  Write a value to the codec register
 *
 *  Parameters: reg - register to write
 *              val - value to write
 *  Return:     true on success, false on error
 *----------------------------------------------------------------------------*/
static bool Codec_Write (uint8_t reg, uint8_t val) {
  uint8_t data[2];
  int32_t n;

  data[0] = reg;
  data[1] = val;
  n = ptrI2C->SendData(CODEC_I2C_ADDR, data, 2, false);
  if (n != 2) return false;

  return true;
}

/*-----------------------------------------------------------------------------
 *      Codec_Read:  Read a value from the codec register
 *
 *  Parameters: reg - register to read
 *              val - variable where value will be stored
 *  Return:     true on success, false on error
 *----------------------------------------------------------------------------*/
bool Codec_Read (uint8_t reg, uint8_t *val) {
  uint8_t data[1];
  int32_t n;

  data[0] = reg;
  n = ptrI2C->SendData(CODEC_I2C_ADDR, data, 1, true);
  if (n != 1) return false;

  n = ptrI2C->ReceiveData(CODEC_I2C_ADDR, val, 1, false);
  if (n != 1) return false;

  return true;
}

/*
* Initialize and Configure the Audio Codec via I2C interface
*/
void configureCodec() {
	uint32_t tick;
	uint32_t i;
	
	Codec_Write(0x02, 0x01);	/* Keep Codec Power-down */
	tick = osKernelSysTick(); /* Wait 10ms */
  while ((osKernelSysTick() - tick) < osKernelSysTickMicroSec(10000));
	
	for (i = 0; i < ARR_SZ(CODEC_Config_Init); i++) {
    Codec_Write (CODEC_Config_Init[i].Addr, CODEC_Config_Init[i].Val);
  }
		
	for (i = 0; i < ARR_SZ(CODEC_Audio_I2S_Slave); i++) {
    Codec_Write (CODEC_Audio_I2S_Slave[i].Addr, CODEC_Audio_I2S_Slave[i].Val);
  }
	
}

/**
	\fn 	CodecInitialize(void)
	\brief Initialize and Configure the Audio Codec
*/
void Codec_Initialize(void) {

uint32_t tick;	
		
	/* Configure I2C */
	ptrI2C->Initialize   (NULL);
  ptrI2C->PowerControl (ARM_POWER_FULL);
  ptrI2C->BusSpeed (ARM_I2C_BUS_SPEED_STANDARD);                
  ptrI2C->BusClear();
	
	/* Configure CODEC */
	configureCodec();
	
	/* Configure I2S */
	I2S_Audio_Initialize();
	
	/* CODEC Power up	*/
	Codec_Write(CS42L52_PWRCTL1, 0x00); 
  /* wait */
	tick = osKernelSysTick(); /* Wait 10ms */
  while ((osKernelSysTick() - tick) < osKernelSysTickMicroSec(10000));

}

/*
*	Generates a beep at the freqency defined by pitch and for
*	time defined by duration.
* Note: Values that can be used with this function for note
* and beep_duration are defined in header codec_CS42L52.h
*/
void Beep(noteInfo note )
{
	Codec_Write(CS42L52_BEEP_VOL, 0x00);	/* Beep off time 1.23s
                                         	 and volume 0dB     */
	Codec_Write(CS42L52_BEEP_FREQ, note.pitch | note.duration);	
	                                      /* Set beep note and	*/ 																												/* beep duration								*/
	Codec_Write(CS42L52_BEEP_TONE_CTL, 0x40);	/* play sgl beep  */	
	Codec_Write(CS42L52_BEEP_TONE_CTL, 0x00);	/* Disable beep		*/
}

/*
* Decreases the volume by 0.5dB when called.
*/
void DecreaseVolume(void) {
	int16_t currentVolume = getVolume();
	const uint16_t minVolume = 0x19; /* -102db * 2 */

	if (currentVolume != minVolume) { /* Check that vol is not at min */
		currentVolume -= 1; //0.5dB decrement
    setVolume(currentVolume);		
	}
}

/*
* Increases the volume by 0.5dB when called.
***************************************************************/
void IncreaseVolume(void)
{
	int16_t currentVolume = getVolume();
	const uint16_t maxVolume = 0x18; /* 12db in 0.5dB steps */
	
	if (currentVolume != maxVolume) { 
		currentVolume += 1; /* 0.5dB increment */
    setVolume(currentVolume);		
	}
}

/*
* Sets volume (-102dB to 12dB)
*/
void setVolume(uint8_t volume) {
	Codec_Write(CS42L52_MASTERA_VOL, (uint8_t) volume);
}

/*
* Returns the Master A volume                                   
***************************************************************/
int16_t getVolume(void)
{
	uint8_t currentVolume;
	//int16_t signedValue = 0;
  Codec_Read(CS42L52_MASTERA_VOL, &currentVolume);
	
//	signedValue |= *currentVolume;
//	if (signedValue > 0x18) {  /* must be -ve */
//		signedValue |= -1 << 8;  /* sign extend */    	
//	}
	
	return currentVolume; 
}

/*
* Mutes the volume
*/
void Mute(void)
{
	Codec_Write(CS42L52_PB_CTL1, 0x01);	/* Set master mute on												*/
}

/*
* UnMutes the volume
*/
void UnMute(void)
{
	Codec_Write(CS42L52_PB_CTL1, 0x00); /* Set master mute off												*/
}
