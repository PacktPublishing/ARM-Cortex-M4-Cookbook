/*--------------------------------------------------
 * Recipe:  codecDemo_c7v0
 * Name:    I2S_audio.c
 * Purpose: SPI2/I2S initialisation
 * Note(s): 
 *--------------------------------------------------
 * Revision History
 * 17.09.2014 Created
 * 18.09.14 Modified to use ARM SPI Framework
 * 03.01.16 Updated CMSIS 4.3.0
 *
 *
 * Mark Fisher, CMP, UEA, Norwich.
 *--------------------------------------------------*/
 
#include "codec_CS42L52.h"
#include "stm32f4xx_hal.h"
#include "I2S_audio.h"
#include "stm32f4xx_hal_i2s.h"

/* Global I2S handle structure */
I2S_HandleTypeDef hi2s;

void Set_I2S_GPIO_Pins(void) {
  GPIO_InitTypeDef GPIO_InitStruct;
  
  __GPIOC_CLK_ENABLE();
  __GPIOI_CLK_ENABLE();
  
    /* Configure GPIO pin: PI0,1,3 */
  GPIO_InitStruct.Pin   = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_3;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull  = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FAST;
  GPIO_InitStruct.Alternate = GPIO_AF5_SPI2;
  HAL_GPIO_Init(GPIOI, &GPIO_InitStruct);
  
  /* Configure GPIO pin: PC6 */
  GPIO_InitStruct.Pin   = GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull  = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FAST;
  GPIO_InitStruct.Alternate = GPIO_AF5_SPI2;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
  
}


/**
  * \fn     I2S_Audio_Initialize(void)
  * \brief  Initialize I2S Bus 
  * @retval HAL_StatusTypeDef
  * @note   
  */
HAL_StatusTypeDef I2S_Audio_Initialize(void) {
  
  HAL_StatusTypeDef status;

  /* Enable the SPIx interface clock. */
	RCC->CR |= RCC_CR_PLLI2SON;  /* Enable the PLLI2S */
	               /* Wait till the main PLL is ready */
	while((RCC->CR & RCC_CR_PLLI2SRDY) == 0)
	{}
  __HAL_RCC_SPI2_CLK_ENABLE();
    
  /* Configure I2S Pins */
  Set_I2S_GPIO_Pins();

  /*-- Set Pointer to I2S Register Base Address --*/
  hi2s.Instance = SPI2;

  /*--- I2S not yet initialized or disabled -- */  
  hi2s.State = HAL_I2S_STATE_RESET;    

  /*-- Reset I2S init structure parameters values --*/
  /* Initialize the I2S_Mode member */
  hi2s.Init.Mode = I2S_MODE_MASTER_TX; //checked
    
  /* Initialize the I2S_Standard member */
  hi2s.Init.Standard = I2S_STANDARD_MSB; //checked
  
  /* Initialize the I2S_DataFormat member */
  hi2s.Init.DataFormat = I2S_DATAFORMAT_16B;  //checked
    
  /* Initialize the I2S_MCLKOutput member */
  hi2s.Init.MCLKOutput = I2S_MCLKOUTPUT_ENABLE; //checked
    
  /* Initialize the I2S_AudioFreq member */
  hi2s.Init.AudioFreq = I2S_AUDIOFREQ_22K;
  
  /* Initialize the I2S_CPOL member */
  hi2s.Init.CPOL = I2S_CPOL_LOW; //checked
  
  /* Initialize the I2S Clock Source */
  hi2s.Init.ClockSource = I2S_CLOCK_PLL ;  // new
  
  /* Initialize the I2S FullDuplexMode */    //new
  hi2s.Init.FullDuplexMode = I2S_FULLDUPLEXMODE_DISABLE;
  
  /* Call the initialise function */
  status = HAL_I2S_Init(&hi2s);
  
  /* Enable the I2S Interrupts*/
  NVIC_EnableIRQ(SPI2_IRQn);
  
  return status;
}
