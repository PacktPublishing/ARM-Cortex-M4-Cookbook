/*--------------------------------------------------
 * Recipe:  adcISR_c5v0
 * Name:    Custom_ADC.c
 * Purpose: ADC Initialize and Enable IRQ
 *--------------------------------------------------
 *
 * Modification History
 * 16.04.14 created
 * 22.12.15 updated uVision5.17+DFP2.6.0
 *
 * Mark Fisher, CMP, UEA, Norwich
 *--------------------------------------------------*/

#include "stm32f4xx_hal.h" /* STM32F4xx Definitions */
#include "Custom_ADC.h"

/*--------------------------------------------------
 * ADC_Initialize_and_Set_IRQ: Initialize Analog to 
 *              Digital Converter and Enable IRQ
 *
 * Parameters:  (none)
 * Return:      (none)
 *--------------------------------------------------*/
void ADC_Initialize_and_Set_IRQ (void) {
   /* Setup potentiometer pin PF9 (ADC3_7) and ADC3 */

  RCC->APB2ENR |= (1UL <<  10);		  /* En. ADC3 clk */
  RCC->AHB1ENR |= (1UL <<   5);    /* En. GPIOF clk */
  GPIOF->MODER |= (3UL << 2*9);/* PF9 is Analog mde */

  ADC3->SQR1   =   0;
  ADC3->SQR2   =   0;
  ADC3->SQR3   =  (7UL <<  0);   /* SQ1 = channel 7 */
	ADC3->SMPR1  =   0;            /* Channel 7 smple */
	ADC3->SMPR2  =   (7UL <<  18); /* time = 480 cyc. */
  ADC3->CR1    =  (1UL <<  8);      /* Scan mode on */
	ADC3->CR2   &= ~2;					/* single conv. mode */
//	ADC3->CR2   |=  2;       /* continuous conv. mode */
	
  ADC3->CR1   |=  ( 1UL <<  5);     /* En. EOC IRQ */
  ADC3->CR2   |=  ( 1UL <<  0);      /* ADC enable */	
	NVIC_EnableIRQ( ADC_IRQn );           /* En. IRQ */	
	ADC3->CR2 |= (1 << 30);  /* Start 1st conversion */
}
