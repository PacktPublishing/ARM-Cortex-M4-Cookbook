/*--------------------------------------------------
 * Name:    Custom_ADC.h
 * Purpose: ADC (special) definitions
 *--------------------------------------------------
 * Dr Mark Fisher, UEA, Norwich, UK
 *--------------------------------------------------*/

#ifndef __CustomADC_H
#define __CustomADC_H

#include <stdint.h>
#include <stdbool.h>

extern void     ADC_Initialize_and_Set_IRQ (void);
//extern void     ADC_Uninitialize    (void);
//extern void     ADC_StartConversion (void);
//extern bool     ADC_ConversionDone  (void);
//extern int32_t  ADC_GetValue        (void);
//extern int32_t  ADC_NumBits         (void);

#endif /* __CustomADC_H */
