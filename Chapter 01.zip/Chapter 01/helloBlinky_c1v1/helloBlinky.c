/*--------------------------------------------------
 * Recipe:  helloBlinky_c1v1  
 * Name:    Blinky.c
 * Purpose: Simultaneous MCBSTM32F400 LED Flasher 
 *--------------------------------------------------
 *
 * Modification History
 * 16.01.14 Created
 * 27.11.15 Updated 
 * (uVision5 v5.17+STM32F4xx_DFP2.6.0)
 *
 * Dr Mark Fisher, CMP, UEA, Norwich, UK
 *--------------------------------------------------*/

#include "stm32F4xx_hal.h"
#include "Board_LED.h"
 
int main (void) {
  const unsigned int Off_Code = 0x0000;
  const unsigned int On_Code = 0x00FF;
  unsigned int i;
	
  LED_Initialize();                      /* LED Init */

  for (;;) {                         /* Loop forever */
		LED_SetOut (On_Code);            /* Turn LEDs on */	
    for (i = 0; i < 1000000; i++)
			/* empty statement */ ;                /* Wait */
		LED_SetOut (Off_Code);          /* Turn LEDs off */
    for (i = 0; i < 1000000; i++)
			/* empty statement */ ;                /* Wait */			
  } /* end for */
}
