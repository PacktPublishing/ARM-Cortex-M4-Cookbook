/*--------------------------------------------------
 *      Name:    RTXBlinkyUtils.c
 *      Purpose: Misc Utils for RTX Blinky
 *--------------------------------------------------
 * 			Modification History                                                       
 * 				Oct. 2015 Created
 * 			Copyright (c) mark.fisher@uea.ac.uk                     
 *--------------------------------------------------*/

#include "RTXBlinkyUtils.h"

void GLCD_setup(void) {

  unsigned char led;

  GLCD_Initialize();							/* Initialise and */
	GLCD_SetBackgroundColor (GLCD_COLOR_WHITE);
  GLCD_ClearScreen ();              /* clear the GLCD */
	GLCD_SetBackgroundColor(GLCD_COLOR_BLUE);    /* Set the Back Color */
	GLCD_SetForegroundColor(GLCD_COLOR_WHITE);
  GLCD_SetFont (&GLCD_Font_16x24);
	GLCD_DrawString(0, 0*24, " CORTEX-M4 COOKBOOK ");
  GLCD_DrawString(0, 1*24, "  PACKT Publishing  ");
	GLCD_SetBackgroundColor(GLCD_COLOR_WHITE);   /* Set the Back Color */
  GLCD_SetForegroundColor(GLCD_COLOR_RED);
  for (led=LED_A; led<LED_G+1; led++)
		GLCD_DrawChar((led+7)*16, 4*24, 0x80+0); 
}
