/*----------------------------------------------------------------------------
 *      Name:    RTXBlinkyGLCDUtils.h
 *----------------------------------------------------------------------------
 * 			Modification History                                                       
 * 				Oct. 2015 Created
 * 			Copyright (c) mark.fisher@uea.ac.uk                     
 *---------------------------------------------------------------------------*/
#ifndef __RTX_BLINKY_GLCD_UTILS_H
#define __RTX_BLINKY_GLCD_UTILS_H

#include "Board_GLCD.h"
#include "GLCD_Config.h"

extern GLCD_FONT     GLCD_Font_16x24;

#define __FI    1                       /* Font index 16x24                  */

#define LED_A   0
#define LED_B   1
#define LED_C   2
#define LED_D   3
#define LED_E   4
#define LED_F   5
#define LED_G   6
#define LED_H   7

/* Function Prototypes */
void GLCD_setup(void);

#endif /* __RTX_BLINKY_GLCD_UTILS_H */
