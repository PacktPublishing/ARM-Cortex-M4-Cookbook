/*--------------------------------------------------
 * Name:    RTXBlinky.h
 *--------------------------------------------------
 * Modification History                                                       
 *   Oct. 2015 Created
 * Copyright (c) mark.fisher@uea.ac.uk                     
 *--------------------------------------------------*/

#ifndef __RTX_BLINKY_H
#define __RTX_BLINKY_H

#include "stm32f4xx_hal.h"        /* STM32F4xx Defs */
#include "Board_LED.h"
#include "cmsis_os.h"

/* Mailbox */
typedef struct {
  uint32_t counter; /* A counter value               */
} mail_t;

osMailQDef(mail_box, 16, mail_t);
osMailQId  mail_box;

/* Task ids */
osThreadId tid_taskA;   
osThreadId tid_taskB;

/* Function Prototypes */
void taskA (void const *argument);
void taskB (void const *argument);

/* Define Threads */
osThreadDef(taskA, osPriorityNormal, 1, 0);
osThreadDef(taskB, osPriorityNormal, 1, 0);

#endif /* __RTX_BLINKY_H */
