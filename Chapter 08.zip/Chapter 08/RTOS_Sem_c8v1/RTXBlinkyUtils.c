/*----------------------------------------------------------------------------
 *      Name:    RTXSemUtils.c
 *      Purpose: Misc Utils for RTX Blinky
 *----------------------------------------------------------------------------
 * 			Modification History                                                       
 * 				Oct. 2015 Created
 * 			Copyright (c) mark.fisher@uea.ac.uk                     
 *---------------------------------------------------------------------------*/

#include "RTXBlinkyUtils.h"

void GLCD_setup(void) {

  GLCD_Initialize();							/* Initialise and */
	GLCD_SetBackgroundColor (GLCD_COLOR_WHITE);
  GLCD_ClearScreen ();              /* clear the GLCD */
	GLCD_SetBackgroundColor(GLCD_COLOR_BLUE);    /* Set the Back Color */
	GLCD_SetForegroundColor(GLCD_COLOR_WHITE);
  GLCD_SetFont (&GLCD_Font_16x24);
	GLCD_DrawString(0, 0*24, " CORTEX-M4 COOKBOOK ");
  GLCD_DrawString(0, 1*24, "  PACKT Publishing  ");
}

void GLCD_show_result(int value) {

  char buffer[128];
  
  GLCD_SetBackgroundColor(GLCD_COLOR_WHITE);   /* Set the Back Color */
  GLCD_SetForegroundColor(GLCD_COLOR_BLACK);  
  GLCD_DrawString (0, 3*24, "VAL =");
  sprintf (buffer, "%i   ", value);	 	/* Convert to string */
  GLCD_DrawString (7*16, 3*24, buffer);		/* Display it */

}

