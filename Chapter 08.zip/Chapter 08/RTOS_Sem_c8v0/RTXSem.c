/*--------------------------------------------------
* Recipe:   RTOS_Sem_c8v0
 * Name:    RTXSem.c
 * Purpose: RTX example program to illustrate need 
 *          for semaphores
 *--------------------------------------------------
 * This code uses the RealView Run-Time Library.
 * Copyright (c) 2004-2013 KEIL - An ARM Company.
 *--------------------------------------------------
 *  Modification History                                                       
 * 	  Oct. 2015 Created
 *    Jan. 2016 Updated
 * 	Copyright (c) mark.fisher@uea.ac.uk                     
 *--------------------------------------------------*/

#include "RTXSem.h"

#define NCYCLES 500000        /* User Modified Value */

int sharedVar;                   /* Shared Variable */

void SystemClock_Config(void);/* Function Prototype */

#ifdef __RTX
extern uint32_t os_time;

uint32_t HAL_GetTick(void) {
  return os_time; 
}
#endif


/**
  * System Clock Configuration
  */
void SystemClock_Config(void) {
  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

  /* Enable Power Control clock */
  __HAL_RCC_PWR_CLK_ENABLE();

  /* The voltage scaling allows optimizing the power consumption when the
     device is clocked below the maximum system frequency (see datasheet). */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /* Enable HSE Oscillator and activate PLL with HSE as source */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  HAL_RCC_OscConfig(&RCC_OscInitStruct);

  /* Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2
     clocks dividers */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_PCLK1 |
                                RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5);
}

/*--------------------------------------------------
 * Thread 1 'taskA': Increment Shared Variable
 *--------------------------------------------------*/
void taskA (void const *argument) {
	uint32_t p;
  bool flag = true;

  for (;;) {
		if (flag==true) {
      /* Inccrement the Shared Variable */
			for (p=0; p<NCYCLES; p++)
				sharedVar++;
      /* set signal to taskC thread   */
			osSignalSet(tid_taskC, 0x0001);
			flag = false;
		}
  }
}

/*--------------------------------------------------
 * Thread 2 'taskB': Decrement Shared Variable
 *--------------------------------------------------*/
void taskB (void const *argument) {
	uint32_t p;
  bool flag = true;

  for (;;) {
		if (flag==true) {
      /* Decrement the Shared Variable */
			for (p=0; p < NCYCLES; p++)
				sharedVar--;
      /* set signal to taskC thread */
			osSignalSet(tid_taskC, 0x0002);
      flag = false;
		}
  }
}

/*--------------------------------------------------
 * Thread 3 'taskC': Display Shared Variable
 *--------------------------------------------------*/
void taskC (void const *argument) {

	for (;;) {
    /* wait for an event flag 0x0003 */
		osSignalWait(0x0003, osWaitForever);    
    GLCD_show_result(sharedVar);
    /* Kill Threads */
    osThreadTerminate (tid_taskA);
    osThreadTerminate (tid_taskB);
    osThreadTerminate (tid_taskC);
	}
}

/*--------------------------------------------------
 * Main: Initialize and start RTX Kernel
 *--------------------------------------------------*/
int main (void) {

  HAL_Init ();   /* Init Hardware Abstraction Layer */
  SystemClock_Config ();           /* Config Clocks */        

  GLCD_setup();

  sharedVar = 0;

  tid_taskA = osThreadCreate(osThread(taskA), NULL);
  tid_taskB = osThreadCreate(osThread(taskB), NULL);
  tid_taskC = osThreadCreate(osThread(taskC), NULL);
  
  osDelay(osWaitForever);
  while(1);
}
