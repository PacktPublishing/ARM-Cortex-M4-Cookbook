/*--------------------------------------------------
 *      Name:    RTXSem.h
 *--------------------------------------------------
 * 			Modification History                                                       
 * 				Oct. 2015 Created
 * 			Copyright (c) mark.fisher@uea.ac.uk                     
 *--------------------------------------------------*/
#ifndef __RTX_SEM_H
#define __RTX_SEM_H

#include "stm32f4xx_hal.h"        /* STM32F4xx Defs */
#include "RTXBlinkyUtils.h"
#include "cmsis_os.h"

/* Thread id of thread: task_a, b, c */
osThreadId tid_taskA;                   
osThreadId tid_taskB;                  
osThreadId tid_taskC;

/* Function Prototypes */
void taskA (void const *argument);
void taskB (void const *argument);
void taskC (void const *argument);

/* Thread Definitions */
osThreadDef(taskA, osPriorityNormal, __FI, 0);
osThreadDef(taskB, osPriorityNormal, __FI, 0);
osThreadDef(taskC, osPriorityNormal, __FI, 0);

#endif /* __RTX_SEM_H */
