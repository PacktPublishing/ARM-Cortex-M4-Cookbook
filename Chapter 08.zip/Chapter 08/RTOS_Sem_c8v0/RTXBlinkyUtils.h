/*--------------------------------------------------
 *      Name:    RTXBlinkyGLCDUtils.h
 *--------------------------------------------------
 * 			Modification History                                                       
 * 				Oct. 2015 Created
 * 			Copyright (c) mark.fisher@uea.ac.uk                     
 *--------------------------------------------------*/
#ifndef __RTX_BLINKY_GLCD_UTILS_H
#define __RTX_BLINKY_GLCD_UTILS_H

#include "Board_GLCD.h"
#include "GLCD_Config.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define __FI    1                       /* Font index 16x24                  */

extern GLCD_FONT     GLCD_Font_16x24;

/* Function Prototypes */
void GLCD_setup(void);
void GLCD_show_result(int );

#endif /* __RTX_BLINKY_GLCD_UTILS_H */
