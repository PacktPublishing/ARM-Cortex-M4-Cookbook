/*----------------------------------------------------
 * Recipe   RTOS_Pongc8v0
 * Name:    RTOS_Pong.c
 * Purpose: CMSIS-RTOS Pong Demo
 * Target:  Keil MCBSTM32F400 Eval. Board
 *----------------------------------------------------
 * This code uses ARM CMSIS-RTOS.
 * Copyright (c) 2004-2013 KEIL - An ARM Company.
 *----------------------------------------------------
 * Modification History                                                       
 * 	Oct. 2015 Created
 *  Jan. 2016 Updated
 * mark.fisher@uea.ac.uk                     
 *--------------------------------------------------*/

#include "stm32f4xx_hal.h"
#include "GLCD_Config.h"
#include "Board_GLCD.h"
#include "cmsis_os.h"
#include "Board_ADC.h"
#include "pong_utils.h"
#include "RTOS_Pong.h"

extern GLCD_FONT     GLCD_Font_16x24;
GameInfo thisGame;

#ifdef __RTX
extern uint32_t os_time;

uint32_t HAL_GetTick(void) {
  return os_time; 
}
#endif

/* Function Prototypes */
void SystemClock_Config(void);

/**
  * System Clock Configuration
  */
void SystemClock_Config(void) {
  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

  /* Enable Power Control clock */
  __HAL_RCC_PWR_CLK_ENABLE();

  /* The voltage scaling allows optimizing the power consumption when the
     device is clocked below the maximum system frequency (see datasheet). */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /* Enable HSE Oscillator and activate PLL with HSE as source */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  HAL_RCC_OscConfig(&RCC_OscInitStruct);

  /* Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2
     clocks dividers */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_PCLK1 |
                                RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5);
}


/*--------------------------------------------------
 *      Thread 1 'taskGLCD':   
 *--------------------------------------------------*/
void taskGLCD (void const *argument) {
  BallInfo init_pstn = thisGame.ball;

	for (;;) {
    osEvent evt = osMailGet(mail_box, osWaitForever);
  	if (evt.status == osEventMail) {
			mail_t *mail = (mail_t*)evt.value.p;
      thisGame.p1.y = mail->pdl;				
  	  osMailFree(mail_box, mail);

			osMutexWait(mut_GLCD, osWaitForever);	
      update_player();
 
			if (thisGame.ball.x<BAR_W) {	 /* reset pstn */	 	
				osDelay(T_LONG);
        erase_ball();		
				thisGame.ball = init_pstn;
			} 
      draw_ball();			
			osMutexRelease(mut_GLCD);

			osDelay(T_SHORT);
			osSignalSet(tid_taskBall, 0x0001);
		}
	}
}

/*--------------------------------------------------
 *      Thread 2 'taskBall':   
 *--------------------------------------------------*/
void taskBall (void const *argument) {

	for (;;) {
    osSignalWait(0x0001, osWaitForever);

    update_ball();   
    check_collision();

    osSignalSet(tid_taskGLCD, 0x0001);
	}
}

/*--------------------------------------------------
 *      Thread 2 'taskADC':   
 *--------------------------------------------------*/
void taskADC (void const *argument) {
uint32_t adcValue;
	for (;;) {
    mail_t *mail = (mail_t*)osMailAlloc(mail_box, 
                                       osWaitForever);
    ADC_StartConversion();
		adcValue = ADC_GetValue ();
    		
		mail->pdl = (adcValue >> 4) * (HEIGHT-BAR_H)/256;
		osMailPut(mail_box, mail);
    osDelay(T_SHORT);
	}
}

/**
 * Main 
 */
int main (void) {
  
  HAL_Init ( );
  SystemClock_Config ( );
	
	game_Initialize();
	ADC_Initialize();
	GLCD_Initialize ();
	GLCD_SetBackgroundColor (GLCD_COLOR_WHITE);
  GLCD_ClearScreen (); 
	GLCD_SetForegroundColor (GLCD_COLOR_BLUE);
  GLCD_SetFont (&GLCD_Font_16x24);

	mail_box = osMailCreate(osMailQ(mail_box), NULL);
  mut_GLCD = osMutexCreate(osMutex(mut_GLCD));
 
  tid_taskGLCD = osThreadCreate(osThread(taskGLCD), NULL);
  tid_taskBall = osThreadCreate(osThread(taskBall), NULL);
  tid_taskADC = osThreadCreate(osThread(taskADC), NULL);

  osDelay(osWaitForever);
  while(1)
    ;
}
