/*-------------------------------------------------
 * Name: pong_utils.h
 * Purpose: Pong Prototype - CMSIS-RTOS Version
 *-------------------------------------------------
 * Modification History                                                       
 *   Oct. 2015 Created
 * Copyright (c) mark.fisher@uea.ac.uk                     
 *-------------------------------------------------*/
#ifndef _PONG_UTILS_H
#define _PONG_UTILS_H

#define WIDTH		320
#define HEIGHT	240
#define CHAR_H  24      /* Char Height (in pixels) */
#define CHAR_W  16      /* Char Width (in pixels)  */
#define BAR_W   6		      /* Bar Width (in pixels) */
#define BAR_H		24			 /* Bar Height (in pixels) */
#define T_LONG	1000                 /* Long delay */
#define T_SHORT 5                   /* Short delay */

extern unsigned short Font_16x24_h[];

typedef struct {
	  int dirn;
	  int x; 
	  int y; 
	} BallInfo;

typedef struct {
	  int x;
	  int y;
	} PaddleInfo;

typedef struct {
	BallInfo ball;
	PaddleInfo p1;
  } GameInfo;

/* Function Prototypes */
void game_Initialize(void);
void erase_ball(void);
void draw_ball(void);
void update_player(void);
void update_ball (void);
void check_collision (void);	

#endif /* _PONG_UTILS_H */
